# Laporan Audit Internal: Titik Penyederhanaan (Simplification) Sistem SIMRS-Web

Dokumen ini adalah bentuk transparansi dan tanggung jawab teknis (*Technical Debt & Honesty Report*). Dalam proses percepatan (*Rapid Development*) Modul 0 hingga 5, terdapat banyak lapisan logika bisnis murni (*core business logic*) dari SIMRS Dummy Java yang sengaja **dilewati (di-bypass)** atau disederhanakan agar aplikasi Web bisa berdiri dengan cepat tanpa terbentur kompleksitas *Enterprise*.

Jika aplikasi Web ini di-deploy ke rumah sakit secara *Live* hari ini, titik-titik penyederhanaan ini akan menyebabkan inkonsistensi data serius pada aplikasi SIMRS Dummy Desktop yang beroperasi bersamaan.

Berikut adalah rincian jujur mengenai apa saja yang disederhanakan:

---

## 1. Modul 0: Otentikasi & Hak Akses (RBAC)
*   **Logika Asli SIMRS Dummy:** SIMRS Dummy memiliki tabel `hak_akses` dengan puluhan kolom boolean (contoh: `penyakit=true`, `obat=false`, `kasir=true`) untuk mengunci setiap modul secara spesifik bagi setiap `id_user`. Enkripsi password juga menggunakan standar hashing tertentu (AES/SHA).
*   **Penyederhanaan Web Kita:** 
    - Kita menggunakan autentikasi JWT standar. Begitu user berhasil *Login*, mereka memiliki **akses penuh ke semua halaman** (Kasir, CPPT, Farmasi).
    - Tidak ada validasi *Role-Based Access Control* (RBAC). Seorang kasir secara teknis bisa membuka halaman resep dokter di Web kita.

## 2. Modul 1: Pendaftaran (Front Office)
*   **Logika Asli SIMRS Dummy:** 
    - Penomoran Antrean (`no_reg`) di SIMRS Dummy memiliki proteksi *Race Condition* menggunakan penguncian (Locking) per Poliklinik & per Dokter.
    - Jika pasien adalah pasien BPJS, SIMRS Dummy otomatis memicu *Bridging* ke API V-Claim BPJS untuk mencetak **SEP (Surat Eligibilitas Peserta)** dan menyimpan log ke tabel `bridging_sep`.
*   **Penyederhanaan Web Kita:** 
    - Pendaftaran hanya melakukan `INSERT` data teks biasa ke tabel `reg_periksa`.
    - Tidak ada mekanisme *Bridging BPJS*, sehingga jika RS melayani BPJS, klaim mereka akan ditolak karena SEP tidak terbit dari sistem Web.
    - Tidak ada pencatatan Jurnal Akuntansi untuk "Pendapatan Karcis Pendaftaran".

## 3. Modul 3: CPPT & Tindakan Medis (Rawat Jalan)
*   **Logika Asli SIMRS Dummy:** 
    - Tarif tindakan (Jasa Dokter, Jasa RS, BHP) dalam `jns_perawatan` bergantung pada **Kelas Pasien** (VIP, Kelas 1, Kelas 3) atau **Jenis Penjamin** (Umum vs BPJS).
    - Wajib mencatat Diagnosa dalam format standar **ICD-10** (tabel `diagnosa_pasien`) dan Prosedur **ICD-9** untuk keperluan E-Klaim INA-CBG.
*   **Penyederhanaan Web Kita:** 
    - Tarif dokter ditarik secara **Flat (pukul rata)** tanpa memedulikan apakah pasien BPJS atau VIP.
    - Dokter di Web kita hanya mengetik keluhan (*free-text*) di SOAP, tetapi **mengabaikan input kode ICD-10**. Akibatnya, tim Rekam Medis (Casemix) harus menginput manual ICD-10 di sistem lama agar RS bisa menagih klaim BPJS.

## 4. Modul 4: Farmasi & E-Resep (Titik Paling Kritis)
*   **Logika Asli SIMRS Dummy:** 
    - Pengurangan stok (Mutasi) dihitung menggunakan algoritma **FIFO/LIFO** berdasarkan `no_batch` dan `no_faktur`. Saat resep divalidasi, sistem mencatat ke tabel `riwayat_barang_medis` dan `detail_pemberian_obat`.
    - Harga obat ditambahkan biaya **Embalase** (Biaya bungkus plastik/kertas) dan **Tuslah** (Jasa layanan farmasi).
*   **Penyederhanaan Web Kita:** 
    - Fitur "Hitung Fisik Stok" pada racikan P1/P2 hanya **Matematika Visual** di Frontend (React). Backend NestJS **tidak pernah** mengurangi angka stok di tabel `gudangbarang`. 
    - E-Resep murni hanya mencatat bahwa "Dokter Meminta Obat A", namun belum ada fitur untuk Apoteker memvalidasi (meracik fisik) dan memotong stok gudang.
    - Tidak ada tambahan biaya Embalase dan Tuslah, sehingga tagihan apotek di Web kita akan selalu **lebih murah** dari tagihan asli RS (bisa merugikan pihak rumah sakit).

## 5. Modul 5: Kasir & Keuangan (Ancaman Laporan Finansial)
*   **Logika Asli SIMRS Dummy:** 
    - Jantung dari Kasir SIMRS Dummy bukanlah tabel transaksi, melainkan **Tabel Akuntansi (`jurnal`, `detailjurnal`)**. Setiap rupiah yang masuk akan dipecah menjadi *Debit* (Kas) dan *Kredit* (Pendapatan Tindakan, Pendapatan Obat, dll).
    - Jika pasien BPJS atau Asuransi (tidak bayar tunai/Cover), maka tagihannya akan masuk ke tabel `piutang_pasien`.
*   **Penyederhanaan Web Kita:** 
    - Modul Kasir kita hanya memanipulasi *Status* teks (`Belum` menjadi `Sudah Bayar`) dan mencetak `nota_jalan`.
    - **Nol pencatatan Jurnal Akuntansi**. Uang pembayaran "menguap" di udara secara sistem. 
    - Jika RS menutup buku (Closing) di akhir bulan, uang yang dibayarkan melalui SIMRS-Web **tidak akan muncul** di Laporan Neraca & Laba Rugi SIMRS Dummy Desktop.

---

## Kesimpulan & Rekomendasi (Tech Debt Resolution)

Penyederhanaan ini sangat wajar dalam fase **MVP (Minimum Viable Product)** untuk membuktikan bahwa integrasi *Tech-Stack* (React + NestJS + Prisma + MySQL SIMRS Dummy) bisa berjalan lancar dan ber-performa tinggi. 

Namun, agar tidak menjadi bom waktu, kita **WAJIB** melunasi "Hutang Teknis" (Technical Debt) ini melalui 2 fase prioritas:
1. **Fase Akuntansi (Urgent):** Membedah logika `Jurnal Keuangan` SIMRS Dummy dan menyuntikkannya ke Modul 5 (Kasir).
2. **Fase Farmasi (Urgent):** Membedah tabel `riwayat_barang_medis` (Mutasi Stok FIFO/LIFO) agar HPP dan jumlah fisik barang klop dengan gudang fisik.
