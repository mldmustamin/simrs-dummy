# Analisis Technology Stack untuk SIMRS Skala Masif (Enterprise)

Membangun ulang SIMRS Dummy secara *full web-based* bukanlah sekadar membuat "aplikasi web biasa". SIMRS Dummy memiliki lebih dari **800-1000 tabel**, ratusan modul, pelaporan (*reporting*) yang berat, pencetakan struk, serta kebutuhan *real-time* (seperti antrean dan pemantauan bangsal).

Jika kita menggunakan pendekatan *Fullstack Monolith* biasa (seperti murni Next.js + Prisma yang saya usulkan sebelumnya), ada risiko arsitektur tersebut akan kewalahan ketika skala aplikasi membengkak.

Berikut adalah analisis mendalam (*Deep Dive*) dan evaluasi opsi *stack* yang paling **stabil, mumpuni, dan *enterprise-ready***.

---

## 1. Analisis Database & ORM (Kelemahan Prisma)

SIMRS Dummy memiliki struktur *database legacy* (lama). Banyak tabel yang mungkin tidak memiliki *Primary Key* yang standar, relasi *Foreign Key* tidak terdefinisi dengan ketat di level *engine*, dan kueri yang sangat kompleks (banyak *JOIN* untuk pelaporan rekam medis).

- ❌ **Prisma ORM:** Prisma sangat dimanjakan untuk *developer experience*, tetapi **kurang cocok** untuk *database legacy* yang sangat masif (1000+ tabel). Prisma akan menghasilkan *file client* yang sangat besar, memakan memori tinggi saat *startup*, dan kesulitan menangani tabel tanpa *Primary Key* yang jelas.
- ✅ **Rekomendasi (Backend/ORM):** **TypeORM**, **MikroORM**, atau **Knex.js (Query Builder)**. 
  - **Knex.js / Drizzle ORM** sangat ringan, berkinerja tinggi, dan memberikan kebebasan absolut untuk menulis kueri SQL kompleks persis seperti yang dilakukan SIMRS Dummy di Java.

## 2. Analisis Backend (API & Business Logic)

Karena Anda mensyaratkan **"tanpa menyisakan Java"**, kita butuh *framework backend* yang ketat (*strict*), modular, dan bisa menangani *background jobs* (misalnya untuk pengiriman bridging klaim BPJS secara asinkron).

- ❌ **Next.js API Routes:** Menyatukan ratusan *endpoint* medis ke dalam folder Next.js akan membuat proyek sangat berantakan (*spaghetti code*) dan sulit dipecah per modul klinis.
- ✅ **Rekomendasi Utama: NestJS (Node.js + TypeScript)**
  - NestJS memiliki struktur arsitektur yang terinspirasi dari Angular dan Spring Boot (Java). Ini adalah rumah yang sempurna bagi mantan *developer* Java.
  - Menggunakan *Dependency Injection*, sangat modular (bisa dipecah per *folder*: Modul Farmasi, Modul Poli, Modul Kasir).
  - Sangat stabil, *enterprise-ready*, dan mumpuni untuk menangani ribuan *request* antrean per detik menggunakan *WebSockets*.
- 🔹 **Alternatif Lain:** **Golang (Go)**. Sangat cepat dan memakan RAM sangat kecil, namun kurvanya sedikit lebih curam dibanding TypeScript.

## 3. Analisis Frontend (User Interface)

Untuk SIMRS, *Search Engine Optimization* (SEO) **tidak penting**. Yang paling penting adalah kecepatan berpindah form, *state management* (misal: menyimpan data pasien sementara dokter membuka tab lab), dan responsivitas.

- ❌ **Next.js (Server-Side Rendering):** *Overkill* dan menambah beban server untuk me-*render* halaman HTML medis secara terus menerus.
- ✅ **Rekomendasi: React SPA (Single Page Application) dengan Vite**
  - **Vite + React + TypeScript:** Sangat cepat untuk di-*build* dan di-*hot-reload*. Beban rendering sepenuhnya ada di komputer klien (browser dokter/perawat), sehingga server bisa fokus memproses data.
  - **State Management:** **Zustand** (untuk menyimpan status global) dan **TanStack Query (React Query)** (untuk *caching* data rekam medis agar tidak perlu berulang kali mengambil data dari server jika tidak ada perubahan).
  - **UI Framework:** **Tailwind CSS + Shadcn UI**. Menjamin konsistensi desain, tampilan modern, dan sangat ringan.

---

## 🏆 Kesimpulan & Rekomendasi Stack Final (Enterprise Grade)

Untuk memastikan aplikasi pengganti SIMRS Dummy ini bertahan hingga 10+ tahun ke depan tanpa masalah skalabilitas, saya merekomendasikan **Pemisahan Frontend & Backend secara tegas (Microservice-Ready Monolith)**:

### ⚙️ BACKEND (Core Engine)
- **Framework:** NestJS (Node.js/TypeScript)
- **Database Engine:** MySQL / MariaDB (Bawaan SIMRS Dummy `sik`)
- **Query Builder/ORM:** Drizzle ORM atau Knex.js
- **Real-time Engine:** Socket.io (untuk pemanggilan antrean otomatis)

### 💻 FRONTEND (Client Web)
- **Framework:** React 18+ (dibangun menggunakan Vite)
- **Language:** TypeScript
- **Styling:** Tailwind CSS + Shadcn UI
- **Data Fetching:** TanStack Query

> [!IMPORTANT]
> **Mengapa Stack ini lebih baik?** 
> Jika kelak rumah sakit memiliki cabang atau beban melebar, modul NestJS dapat dengan mudah dipisah menjadi *microservices*, dan React Frontend dapat di-hosting secara statis dan murah di mana saja (bahkan di CDN), sehingga beban server utama (NAS/Server RS) murni hanya menangani pertukaran data (API) dan Database.

## 🗣️ Permintaan Keputusan
Apakah Anda setuju kita mengubah rencana ke **NestJS (Backend)** dan **Vite+React (Frontend)** sebagai fondasi Enterprise kita? Jika ya, saya akan segera memperbarui *Implementation Plan* kita sesuai dengan standar arsitektur tingkat tinggi ini.

---

## 🛡️ Arsitektur Antisipatif (Bridging BPJS & Kemenkes)

Standar *Web Service* pemerintah (BPJS V-Claim, Antrean Online, E-Klaim INA-CBG, SatuSehat Kemenkes) terkenal sangat dinamis dan sering mengalami pembaruan versi (v1.0 ➔ v2.0 ➔ v2.1) yang bisa merusak integrasi RS jika tidak diantisipasi.

Untuk SIMRS-Web ini, kita **wajib** menggunakan strategi arsitektur pertahanan berikut:

### 1. Pola Desain "Adapter" & "Facade" (Isolasi API)
- **Jangan pernah menyematkan URL atau Logika API BPJS langsung ke Controller/Service utama (seperti `PendaftaranService`).**
- Kita akan membuat **`BpjsAdapterService`** terpisah yang bertindak sebagai jembatan. Jika BPJS mengubah parameter JSON-nya dari `noKartu` menjadi `no_kartu_bpjs`, kita HANYA perlu mengubahnya di satu file *Adapter* ini. Controller internal kita tidak akan menyadari adanya perubahan tersebut.

### 2. Versioning URL (v1, v2) di Environment
- Semua *Base URL* dan *Endpoint* akan disimpan di file `.env`.
- Jika ada *bridging* versi baru yang diluncurkan, kita membuat *Adapter V2* secara paralel tanpa menghapus V1. Jika V2 gagal saat uji coba *production*, kita bisa menggunakan *switch* (Feature Toggle) di file `.env` untuk mundur (rollback) seketika ke V1 tanpa *downtime*.

### 3. Asynchronous Log & Retry Mechanism (Pencegahan Timeout)
- Server BPJS atau INA-CBG sering *down* atau lambat.
- Kita akan menggunakan **Message Queue (BullMQ / Redis)** di dalam NestJS. Saat kasir / rekam medis mengirim klaim, statusnya diset `PENDING_SYNC`.
- *Background Job* akan mencoba mengirimkannya ke server pemerintah. Jika gagal (RTO/500 Error), sistem akan melakukan *Auto-Retry* (mengulang otomatis) 3 kali dengan jeda waktu, tanpa membuat layar *loading* petugas RS menjadi hang (*blocking*).

### 4. Shadow Mapping (Tabel Mapping Internal)
- Kita tetap mematuhi tabel *mapping* warisan SIMRS Dummy (seperti `maping_poli_bpjs`, `maping_obat_apotek_bpjs`) agar data RS tidak rusak. Jika BPJS merilis referensi baru, kita cukup memperbarui tabel *mapping* tersebut via UI Admin tanpa perlu mengubah satu baris pun kode pemrograman.
