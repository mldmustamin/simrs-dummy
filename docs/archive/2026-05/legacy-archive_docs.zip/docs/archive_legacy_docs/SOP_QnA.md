# QnA Standard Operating Procedure (SOP) SIMRS-Web

Dokumen ini berisi kumpulan Pertanyaan dan Jawaban (QnA) fundamental yang menjadi landasan arsitektur dan operasional pembuatan SIMRS-Web. Dokumen ini wajib dibaca oleh seluruh anggota tim pengembang untuk menyelaraskan frekuensi kerja dan mencegah disrupsi pada sistem SIMRS Dummy Desktop (Java) yang sedang berjalan.

---

### 1. Proses Pengembangan (Workflow)

**Q: Mengapa kita WAJIB membuat skrip simulasi Python (Dry-Run) sebelum mulai meng-coding di NestJS atau React?**
**A:** MariaDB SIMRS Dummy memiliki struktur *Foreign Key* dan batasan (*constraint*) relasional yang sangat ketat warisan 10+ tahun lalu. Melakukan tes tembak (INSERT/UPDATE) langsung melalui ORM Prisma tanpa validasi berisiko menyebabkan data *corrupt* atau server macet. Skrip Python (*Dry-Run*) menguji logika SQL mentah dan selalu diakhiri dengan perintah `rollback()`, sehingga kita bisa mendeteksi error relasi 100% aman tanpa mengotori data asli rumah sakit.

**Q: Bolehkah kita melakukan *Auto-Introspection* (menarik otomatis) seluruh 800+ tabel SIMRS Dummy ke dalam Prisma Schema?**
**A:** **TIDAK BOLEH.** Menarik ratusan tabel akan menghasilkan *Prisma Client* yang berukuran raksasa, memperlambat proses *build*, dan memakan RAM server yang sangat besar. SOP kita adalah **Pemetaan Terfokus (Targeted Mapping)**: kita hanya memetakan tabel yang benar-benar dibutuhkan per modul yang sedang dibangun.

---

### 2. Integritas Database

**Q: Beberapa tabel di SIMRS Dummy (seperti `resep_dokter` atau `detail_pemberian_obat`) tidak memiliki *Primary Key* tunggal (ID). Bagaimana cara ORM modern menanganinya?**
**A:** Jangan pernah menambahkan kolom *Auto-Increment* atau ID baru pada struktur asli MariaDB. Solusinya, kita merakit **Komposit ID** langsung di lapisan Prisma Schema (contoh: `@@id([no_rawat, kode_brng, tgl_perawatan, jam])`). Hal ini menjamin ORM bisa beroperasi sempurna dan aplikasi Java lama tetap berjalan normal.

**Q: Bolehkah mengubah tipe data atau memperpanjang batas VARCHAR di tabel SIMRS Dummy untuk mengakomodasi input Web yang panjang?**
**A:** **HARAM HUKUMNYA.** Segala bentuk alterasi DDL (*Data Definition Language*) seperti `ALTER TABLE` atau perubahan tipe data dilarang keras (Zero-Modification Policy). Lakukan semua manipulasi, pemotongan, atau konversi tipe data di level *Service* Backend (NestJS).

---

### 3. Penanganan Data Spesifik (Format & Waktu)

**Q: Bagaimana format pengiriman data waktu (Date/Time) dari API ke Database?**
**A:** SIMRS Dummy **memisahkan** kolom tanggal dan waktu. Anda DILARANG mengirim objek *Date/Timestamp* murni (seperti `2026-05-26T08:00:00Z`).
- Untuk Tanggal (Kolom `tgl_...`): Gunakan string **`YYYY-MM-DD`**.
- Untuk Jam (Kolom `jam_...`): Gunakan string **`HH:MM:SS`**.
Pemisahan (*splitting*) ini adalah tanggung jawab backend sebelum kueri dieksekusi.

**Q: Bagaimana dengan format nomor rawat (Primary Identifier)?**
**A:** Selalu gunakan format *slashes*: **`YYYY/MM/DD/xxxxxx`**. Jangan pernah membuat format kustom atau men- *generate* UUID, karena ini akan memutuskan relasi data dengan antrean poli dan tagihan kasir.

---

### 4. Arsitektur Lanjutan (Bridging & UI)

**Q: Bagaimana strategi menghadapi API BPJS Kesehatan dan E-Klaim INA-CBG yang sering berubah-ubah secara mendadak?**
**A:** Kita tidak menyematkan *URL Endpoint* secara *hardcode*. SOP kita menggunakan **Pola Desain Adapter (Adapter Pattern)** (contoh: `BpjsAdapterService`) yang terisolasi dari modul inti (pendaftaran/kasir), serta menerapkan **Versioning API (V1, V2)** di `.env` file dengan sistem *Feature Toggle*. Jika API versi baru bermasalah, kita bisa *rollback* instan ke versi lama tanpa *downtime*.

**Q: Mengapa transaksi farmasi dan kasir sebaiknya menggunakan teknik On-the-fly Calculation (Penghitungan Langsung) di Frontend/Layar Kasir?**
**A:** Agar kasir bisa melihat rincian (*preview*) harga teraktual (jika ada pembatalan obat detik terakhir) sebelum transaksi benar-benar dikunci dan dimasukkan (INSERT) ke tabel `billing`.

**Q: Desain antarmuka (UI) apa yang diwajibkan untuk aplikasi ini?**
**A:** *Glassmorphism* modern menggunakan Tailwind CSS + Shadcn UI. Tampilan harus bersih, meminimalisir *klik* berlebih bagi dokter, dan menonjolkan fitur pencarian yang reaktif (tanpa memuat ulang halaman).

---
*Dokumen ini bersifat dinamis (Living Document). Jika ada kasus *edge-case* baru yang disepakati oleh tim, wajib segera didokumentasikan di sini.*
