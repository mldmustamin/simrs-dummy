# Technical Debt Resolution Checklist

## Phase 1: Resolusi Finansial & Inventori (Tingkat Kritis)
- `[x]` Update Prisma Schema: Tambahkan `jurnal`, `detailjurnal`, `rekening`, `riwayat_barang_medis`, `set_embalase`
- `[x]` Backend Kasir: Implementasi Sistem Akuntansi Double-Entry (`jurnal` & `detailjurnal`) di `kasir.service.ts`
- `[x]` Backend Farmasi: Implementasi Pemotongan Stok FIFO (`gudangbarang`) & `riwayat_barang_medis`
- `[x]` Backend Farmasi: Masukkan Biaya Embalase & Tuslah ke tagihan Kasir
- `[/]` **Honest Clean & Clear Check (Fase 1)**

## Phase 2: Resolusi Legal & Rekam Medis BPJS (Tingkat Krusial)
- `[ ]` Update Prisma Schema: Tambahkan `bridging_sep`, `diagnosa_pasien`, `penyakit`
- `[ ]` Backend Pendaftaran: Memicu penerbitan SEP BPJS (Mock API / Real API)
- `[ ]` Backend CPPT: Implementasi Wajib ICD-10 saat Dokter menyimpan SOAP
- `[ ]` Frontend CPPT: AutoComplete Search ICD-10
- `[ ]` **Honest Clean & Clear Check (Fase 2)**

## Phase 3: Resolusi Arsitektur (RBAC) & Kosmetik (Tingkat Menengah & Ringan)
- `[ ]` Update Prisma Schema & Auth: Kaitkan token JWT dengan boolean akses di tabel `user`
- `[ ]` Frontend App.tsx: Terapkan `<ProtectedRoute requiredRole="...">`
- `[ ]` Frontend UI: Terapkan Server-Side Pagination & Cegah Out of Memory
- `[ ]` **Honest Clean & Clear Check (Fase 3)**
