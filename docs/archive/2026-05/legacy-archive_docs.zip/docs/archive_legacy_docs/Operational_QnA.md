# QnA Logika Operasional SIMRS-Web

Dokumen ini adalah **Buku Pintar Alur Bisnis (Business Logic)** yang merekam cara kerja sistem rumah sakit dari hulu ke hilir. Dibuat berdasarkan integrasi murni terhadap database SIMRS Dummy yang telah kita bangun pada Modul 0 hingga Modul 4.1. 

Dokumen ini sangat berguna untuk melatih staf rumah sakit (Perawat, Dokter, Kasir) maupun referensi bagi analis sistem.

---

### 1. Pendaftaran & Registrasi (Front Office)

**Q: Apakah bisa mendaftarkan pasien secara langsung ke Rawat Inap (Direct Admission) tanpa melewati pendaftaran Poli/IGD terlebih dahulu?**
**A:** **Tidak bisa.** Sistem database SIMRS Dummy memiliki perlindungan *Foreign Key* yang ketat. Semua pasien, apa pun tujuannya, harus melalui loket pendaftaran (`reg_periksa`) untuk mendapatkan **Nomor Rawat** (`no_rawat`) terlebih dahulu. Baru setelah itu pasien bisa dimutasi/di-admisi ke bangsal Rawat Inap.

**Q: Bagaimana format penomoran antrean dan pendaftaran di aplikasi ini?**
**A:** Nomor rawat dibuat otomatis oleh sistem mengikuti format baku **`YYYY/MM/DD/NoUrut`** (contoh: `2026/05/26/000001`). Nomor inilah yang menjadi *kunci master* (Primary Key) yang mengikat data pasien di Poli, Apotek, hingga Kasir.

---

### 2. Rekam Medis & Pelayanan Dokter (CPPT)

**Q: Saat dokter ingin melihat riwayat penyakit pasien (SOAP), apakah data Rawat Jalan dan Rawat Inap dipisah?**
**A:** Di antarmuka aplikasi SIMRS-Web kita, **keduanya digabung dalam satu layar kronologis** (Timeline). Namun di latar belakang (database), SIMRS Dummy memisahkannya ke dalam tabel `pemeriksaan_ralan` dan `pemeriksaan_ranap`. Sistem kita cerdas menarik keduanya dan mengurutkannya secara visual berdasarkan waktu (Real-time).

**Q: Mengapa dokter harus menginput diagnosa menggunakan standar ICD-10?**
**A:** Penggunaan ICD-10 (`diagnosa_pasien`) sangat krusial, bukan hanya untuk rekam medis, tetapi karena ini adalah **syarat mutlak** jika pasien tersebut menggunakan asuransi BPJS. Tanpa kode ICD-10 yang valid, sistem E-Klaim INA-CBG kelak tidak akan bisa mengkalkulasi tarif klaim tagihan ke pemerintah.

---

### 3. Layanan Farmasi & E-Resep

**Q: Apakah sistem mencegah dokter meresepkan obat yang stoknya kosong?**
**A:** Di versi SIMRS-Web, dokter diberikan fitur "Cek Stok" secara *real-time* ke semua gudang/bangsal (tabel `gudangbarang`) sebelum meresepkan. Hal ini menekan risiko pasien ditolak di loket apotek karena obat habis. 

**Q: Apa bedanya "Obat Jadi" dan "Obat Racikan" di E-Resep kita?**
**A:** 
- **Obat Jadi:** Obat yang langsung diberikan dalam bentuk aslinya (misal: Paracetamol 500mg, 10 Tablet).
- **Obat Racikan:** Merupakan campuran beberapa obat. Dokter diwajibkan menentukan Metode (Puyer/Kapsul), Jumlah Kemasan, dan pecahan takaran (**P1/P2**). *Contoh:* Jika Paracetamol dibelah dua untuk 10 bungkus puyer, sistem akan memotong stok fisik apotek sebanyak 5 Tablet. Kalkulasi desimal ini terjadi secara presisi dan otomatis.

**Q: Kapan stok obat di Gudang Farmasi benar-benar berkurang secara fisik?**
**A:** Stok fisik di database **belum** berkurang saat dokter menekan tombol "Kirim E-Resep". E-Resep masih berstatus pesanan/draft di apotek. Stok baru akan dipotong secara *real-time* ketika Apoteker melakukan **Validasi Penyerahan Obat**.

---

### 4. Kasir & Keuangan (Billing)

**Q: Dari mana Kasir mendapatkan nominal tagihan (Billing) pasien?**
**A:** Sistem Kasir SIMRS-Web tidak menginput harga secara manual. Ia secara dinamis (*On-the-fly*) mengumpulkan tagihan dari 3 sumber utama:
1. **Pendaftaran:** Biaya admin / retribusi poli (`reg_periksa.biaya_reg`).
2. **Pelayanan Medis:** Biaya tindakan dokter atau perawat (`rawat_jl_dr.biaya_rawat`).
3. **Farmasi:** Total harga obat yang telah divalidasi/diserahkan oleh apoteker (`detail_pemberian_obat`).

**Q: Mengapa obat yang ada di E-Resep kadang tidak muncul di tagihan Kasir?**
**A:** Karena alur bisnis mewajibkan obat harus berstatus **"Diserahkan"** oleh Apotek (pindah dari `resep_obat` ke `detail_pemberian_obat`). Jika belum diserahkan, obat tersebut belum dianggap sah sebagai beban tagihan pasien.

**Q: Apa yang terjadi jika Kasir menekan tombol "Proses Pembayaran"?**
**A:** Sistem akan mencetak `nota_jalan` dan mengunci seluruh tabel yang berkaitan (Pendaftaran, Tindakan, Obat) dengan mengubah statusnya (`stts_bayar`) menjadi **'Sudah'**. Ini mencegah terjadinya pembayaran ganda atau pembatalan sepihak setelah struk tercetak.

---
*Dibuat oleh AI Agent (Antigravity) berdasarkan analisis struktur database SIMRS Dummy.*
