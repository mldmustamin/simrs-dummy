# Codex Project Brief: SIMRS Web

**Tanggal analisis:** 26 Mei 2026  
**Basis analisis:** source code, skema Prisma, skrip simulasi, dokumentasi repository, dan hasil build/test lokal.  
**Status dokumen:** baseline teknis kondisi implementasi saat ini, bukan pernyataan kesiapan produksi.

## 1. Ringkasan Eksekutif

SIMRS Web adalah proyek modernisasi antarmuka dan layanan aplikasi untuk ekosistem
SIMRS Dummy. Proyek ini membangun aplikasi web React dan API NestJS di atas
database MariaDB `sik` milik SIMRS Dummy, dengan tujuan mempertahankan interoperabilitas
dengan aplikasi desktop lama.

Prinsip arsitektur terpenting yang ditemukan dalam repository adalah:

- Aplikasi baru memakai database operasional SIMRS Dummy yang sama.
- Skema tabel bawaan SIMRS Dummy tidak boleh diubah oleh proyek web.
- Pengembangan fitur didahului atau disertai simulasi SQL terhadap struktur riil
  database, umumnya dengan `rollback` untuk membuktikan relasi tanpa menyimpan
  data pengujian.

Source code saat ini sudah mencakup alur aplikasi dari autentikasi, pencarian dan
registrasi pasien, antrean, admisi bed, pencatatan RME/CPPT dan ICD-10, e-resep
obat jadi/racikan, sampai billing dan pembayaran kasir. Namun implementasinya
masih berada pada tahap prototype terintegrasi: terdapat hard-coded configuration
dan data input default, kontrol akses API belum diterapkan, dashboard belum
menggunakan data riil, serta verifikasi otomatis belum sehat.

## 2. Tujuan Produk

### Tujuan utama

Menyediakan pengalaman kerja berbasis web untuk proses rumah sakit yang sebelumnya
ditangani dalam SIMRS Dummy desktop, tanpa memutus kompatibilitas data dan proses
legacy.

### Nilai yang ditawarkan

- Antarmuka web untuk akses modul operasional utama rumah sakit.
- Integrasi langsung dengan master data dan transaksi SIMRS Dummy.
- Alur pelayanan terhubung: registrasi -> pemeriksaan -> resep -> pembayaran.
- Pendekatan validasi berbasis simulasi untuk menekan risiko terhadap database
  legacy yang sudah berjalan.

### Batasan utama

- Database SIMRS Dummy adalah sumber kebenaran dan mempunyai constraint serta konvensi
  lama yang harus diikuti.
- Proyek tidak mempunyai migration workflow untuk memodifikasi tabel inti SIMRS Dummy.
- Banyak keputusan implementasi masih mengandalkan identifier dan asumsi data
  contoh, sehingga belum dapat dianggap siap digunakan tanpa hardening.

## 3. Cakupan Fungsional Aktual

| Area | Kapabilitas yang ditemukan dalam source | Tingkat implementasi aktual |
| --- | --- | --- |
| Autentikasi | Login terhadap tabel `admin` SIMRS Dummy melalui `AES_DECRYPT`, menghasilkan JWT 8 jam | Backend dan layar login tersedia; proteksi endpoint belum terlihat |
| Pasien dan registrasi | Pencarian pasien, detail pasien, pembuatan `reg_periksa`, nomor rawat dan antrean | API dan UI tersedia; poli/dokter UI masih default/dummy |
| Antrean poli | Pengambilan antrean hari ini berstatus `Belum`, polling tampilan setiap 5 detik | API dan tampilan tersedia |
| Bed rawat inap | Daftar kamar `KOSONG`, admisi pasien ke `kamar_inap`, ubah status kamar menjadi `ISI` | API transaksi dan tampilan tersedia; alur input masih manual |
| RME / CPPT | Riwayat SOAP rawat jalan/inap, input SOAP rawat jalan, riwayat/tambah diagnosa, pencarian ICD-10 | API dan tampilan tersedia; identitas petugas UI masih default |
| Farmasi | Pencarian obat, stok gudang, metode racik, resep obat jadi, resep racikan beserta komponen | API dan tampilan tersedia; nomor rawat/dokter UI memiliki nilai contoh |
| Kasir | Agregasi tagihan registrasi/tindakan/obat, pembayaran, nota, mutasi stok, jurnal dan detail jurnal | API dan tampilan tersedia; logika stok/penomoran perlu penguatan |
| Dashboard | Kartu total pasien, pendapatan, poli aktif | Tampilan statis, belum terhubung API |

### Perbedaan dengan dokumentasi lama

`README.md` induk masih menyebut Modul 4 Farmasi sebagai tahap yang segera dimulai.
Source saat analisis justru sudah memuat modul Farmasi, resep racikan, Kasir,
model akuntansi, UI masing-masing, dan skrip simulasi terkait. Karena itu, status
dalam brief ini ditentukan dari implementasi source, bukan hanya roadmap lama.

## 4. Pengguna dan Alur Operasional

### Peran pengguna yang tersirat

Repository belum memiliki role-based authorization terperinci. Secara fungsional,
layar mengindikasikan kebutuhan peran berikut:

| Peran kerja | Aktivitas utama dalam aplikasi |
| --- | --- |
| Admin/operator | Login dan akses umum sistem |
| Petugas pendaftaran | Cari pasien dan membuka kunjungan rawat jalan |
| Petugas antrean | Memantau urutan antrean poli |
| Petugas rawat inap | Memilih kamar kosong dan melakukan admisi |
| Dokter/perawat | Melihat dan mengisi CPPT/SOAP serta diagnosa ICD-10 |
| Farmasi | Membuat e-resep obat jadi atau racikan dan memeriksa stok |
| Kasir | Melihat tagihan, menerima pembayaran, menghasilkan nota/jurnal |

### Alur end-to-end yang ditargetkan source

1. Pengguna login menggunakan akun yang tersimpan pada tabel admin SIMRS Dummy.
2. Petugas mencari pasien dan membuat kunjungan pada `reg_periksa`.
3. Kunjungan muncul dalam antrean poli; bila diperlukan pasien dapat ditempatkan
   ke kamar rawat inap.
4. Tenaga klinis mencatat SOAP/CPPT dan diagnosa ICD-10 untuk kunjungan.
5. Farmasi membuat resep obat jadi atau racikan yang terikat pada `no_rawat`.
6. Kasir mengagregasi biaya registrasi, tindakan, dan resep; proses pembayaran
   mengubah status bayar serta mencoba mencatat nota, mutasi stok, dan jurnal.

## 5. Arsitektur Sistem

```text
Pengguna Rumah Sakit
       |
       v
React + Vite + Tailwind (port pengembangan 5173)
       |
       | HTTP fetch langsung ke http://localhost:3000
       v
NestJS REST API (port default 3000)
       |
       | Prisma ORM + beberapa raw SQL
       v
MariaDB database `sik` milik SIMRS Dummy
       ^
       |
Aplikasi SIMRS Dummy legacy tetap memakai database yang sama

simulation/*.py -> koneksi MariaDB langsung -> dry-run/rollback validasi tabel
```

### Komponen repository

| Direktori | Peran |
| --- | --- |
| `simrs-backend/` | Layanan REST NestJS, Prisma schema, unit/e2e test template |
| `simrs-frontend/` | Single-page application React dan layar modul |
| `simulation/` | Eksplorasi schema, skrip validasi SQL, notebook, data uji |
| `README.md` | Konteks arsitektur awal dan aturan interoperabilitas SIMRS Dummy |

### Stack teknologi

| Lapisan | Teknologi yang ditemukan |
| --- | --- |
| Frontend | React 19, TypeScript, Vite 8, React Router, Tailwind CSS 4, Lucide React |
| Backend | NestJS 11, TypeScript, JWT module |
| Data access | Prisma Client 5 serta query SQL mentah untuk kebutuhan tertentu |
| Database | MySQL provider Prisma yang diarahkan ke MariaDB/SIMRS Dummy `sik` |
| Simulasi | Python, `mysql.connector`, notebook Jupyter |
| Testing | Jest/Supertest pada backend; ESLint/build tooling pada frontend |

## 6. Backend dan Kontrak API

Backend dipusatkan pada `AppModule`, yang memasang modul autentikasi, Prisma,
pasien, registrasi, antrean, bed, RME, farmasi, dan kasir. CORS diaktifkan secara
global dan server mendengar pada `PORT` atau port `3000`.

### Endpoint yang tersedia

| Modul | Method dan path | Fungsi |
| --- | --- | --- |
| Base | `GET /` | Health/greeting scaffold |
| Auth | `POST /api/auth/login` | Validasi admin SIMRS Dummy dan membuat JWT |
| Pasien | `GET /api/patients/search?q=` | Cari pasien berdasarkan nama, NIK, atau no. RM |
| Pasien | `GET /api/patients/:rm` | Ambil detail pasien |
| Registrasi | `POST /api/registrations` | Membuat registrasi rawat jalan |
| Antrean | `GET /api/queues/today` | Daftar antrean belum dilayani hari ini |
| Bed | `GET /api/beds/available` | Daftar tempat tidur tersedia |
| Bed | `POST /api/beds/admit` | Admisi pasien ke tempat tidur |
| RME | `GET /api/rme/cppt/:rm` | Riwayat SOAP/CPPT pasien |
| RME | `POST /api/rme/soap` | Simpan SOAP rawat jalan |
| RME | `GET /api/rme/diagnoses/:rm` | Riwayat diagnosa pasien |
| RME | `POST /api/rme/diagnosis` | Tambahkan diagnosa ICD-10 |
| RME | `GET /api/rme/icd10?q=` | Cari master ICD-10/penyakit |
| Farmasi | `GET /farmasi/obat?keyword=` | Cari obat aktif |
| Farmasi | `GET /farmasi/stok?kode_brng=` | Ambil stok obat per bangsal |
| Farmasi | `GET /farmasi/metode-racik` | Master metode racikan |
| Farmasi | `POST /farmasi/resep` | Membuat resep jadi/racikan |
| Kasir | `GET /kasir/tagihan/:no_rawat` | Menghitung rincian tagihan |
| Kasir | `POST /kasir/bayar` | Melakukan pembayaran dan pencatatan terkait |

### Catatan kontrak API

- Prefix endpoint tidak konsisten: modul awal memakai `/api/...`, sedangkan
  Farmasi dan Kasir memakai root `/farmasi` dan `/kasir`.
- Controller memakai payload tanpa DTO tervalidasi (`any` atau tipe lokal).
- Login menghasilkan access token, tetapi tidak ditemukan `AuthGuard` atau
  kebutuhan header `Authorization` pada endpoint modul.
- Frontend mengunci URL API ke `http://localhost:3000`, sehingga belum mempunyai
  konfigurasi environment untuk deployment.

## 7. Model Data dan Integrasi SIMRS Dummy

`prisma/schema.prisma` memetakan subset tabel SIMRS Dummy yang dibutuhkan aplikasi.
Model tersebut tidak menunjukkan migration tambahan; peran schema Prisma dalam
proyek ini adalah akses terhadap struktur legacy terpilih.

### Kelompok data utama

| Domain | Tabel/model penting |
| --- | --- |
| Identitas dan autentikasi | `admin`, `pegawai`, `user` |
| Pasien dan kunjungan | `pasien`, `penjab`, `poliklinik`, `dokter`, `reg_periksa` |
| Rawat inap | `bangsal`, `kamar`, `kamar_inap` |
| Klinis | `pemeriksaan_ralan`, `pemeriksaan_ranap`, `penyakit`, `diagnosa_pasien`, `jns_perawatan`, `rawat_jl_dr` |
| Farmasi | `databarang`, `gudangbarang`, `resep_obat`, `resep_dokter`, `metode_racik`, `resep_dokter_racikan`, `resep_dokter_racikan_detail`, `detail_pemberian_obat` |
| Billing dan akuntansi | `nota_jalan`, `rekening`, `jurnal`, `detailjurnal`, `riwayat_barang_medis`, `set_embalase` |

### Relasi proses penting

- `pasien` terhubung ke kunjungan melalui `reg_periksa.no_rkm_medis`.
- Nomor rawat `reg_periksa.no_rawat` menjadi referensi utama untuk rawat inap,
  CPPT, diagnosis, tindakan, resep, dan nota.
- Admisi rawat inap membutuhkan `no_rawat` yang sudah valid sebelum membuat
  `kamar_inap`.
- CPPT menghubungkan petugas melalui `nip` ke `pegawai.nik`.
- Resep menghubungkan kunjungan dan dokter, sedangkan kasir mengambil data resep
  untuk perhitungan biaya obat serta mutasi stok.

### Aturan kompatibilitas yang harus dipertahankan

- Jangan mengubah tabel inti atau enum/data convention SIMRS Dummy tanpa analisis
  dampak terhadap aplikasi legacy.
- Nomor rawat, status bayar, status kunjungan, referensi pegawai, dan referensi
  gudang harus mengikuti nilai yang diterima oleh database SIMRS Dummy.
- Operasi multi-tabel yang berdampak finansial atau stok harus atomik serta
  diuji terhadap data salinan sebelum dijalankan di lingkungan operasional.

## 8. Frontend

Frontend berupa SPA dengan rute langsung menuju masing-masing layar modul.

| Route UI | Layar | Integrasi saat ini |
| --- | --- | --- |
| `/login` | Login SIMRS Web | Memanggil login API dan menyimpan token/user pada `localStorage` |
| `/dashboard` | Ringkasan operasional | Angka masih statis |
| `/registration` | Pendaftaran pasien | Pencarian dan registrasi; poli/dokter default |
| `/queues` | Tampilan antrean | Polling API antrean setiap 5 detik |
| `/beds` | Manajemen kamar | Daftar kamar dan input `no_rawat` manual |
| `/rme` | CPPT/SOAP dan diagnosa | Baca/tulis klinis; NIP petugas default |
| `/farmasi` | E-resep dan racikan | Resep terhubung API; no. rawat/dokter default |
| `/kasir` | Billing dan checkout | Tagihan serta proses bayar terhubung API |

### Kematangan UX saat ini

- Layar modul operasional telah tersedia dan cukup untuk demonstrasi alur.
- Tidak ditemukan layout navigasi aplikasi terpadu atau route guard.
- Banyak aksi menggunakan `alert` dan input bebas; belum ada validasi form,
  loading/error handling konsisten, atau selection berbasis master data lengkap.
- Token login disimpan tetapi tidak berperan pada akses layar maupun akses API.

## 9. Simulasi dan Validasi Domain

Direktori `simulation/` merupakan knowledge base praktis untuk perilaku database
SIMRS Dummy. Skrip yang ditemukan mencakup:

| Skrip | Tujuan |
| --- | --- |
| `auth_simulation.py` | Memvalidasi pola autentikasi tabel admin |
| `modul1_patient.py` | Cari pasien dan dry-run registrasi |
| `modul2_queue_bed.py` | Antrean, ketersediaan bed, dan dry-run admisi |
| `modul3_rme_cppt.py` | CPPT, diagnosis, tindakan, serta insert klinis rollback |
| `modul4_farmasi.py` | Obat/stok dan resep obat jadi rollback |
| `modul4_1_racikan_simulation.py` | Metode racik dan detail resep racikan rollback |
| `modul5_kasir_simulation.py` | Agregasi tagihan dan pembayaran rollback |
| `verify_phase1.py`, `verify_300.py` | Pemeriksaan transaksi API/database berbasis data uji |

### Observasi validasi

- Skrip modul inti secara desain menggunakan rollback untuk operasi dry-run.
- Beberapa skrip verifikasi pembayaran tampak ditujukan untuk transaksi nyata
  terhadap data uji, bukan semata-mata dry-run; penggunaannya harus dikontrol.
- Nilai host, database, dan credential masih tertanam dalam beberapa skrip dan
  dokumentasi, sehingga repository perlu dibersihkan sebelum distribusi.
- Skrip simulasi tidak dijalankan dalam analisis ini karena tujuan dokumen adalah
  memotret source, dan eksekusi dapat berinteraksi langsung dengan database.

## 10. Hasil Pemeriksaan Teknis Saat Analisis

Pemeriksaan dijalankan pada 26 Mei 2026 dari workspace lokal ini.

| Pemeriksaan | Hasil | Arti |
| --- | --- | --- |
| `simrs-backend: npm run build` | Berhasil | Source backend dapat dikompilasi |
| `simrs-backend: npm run test -- --runInBand` | Gagal: 16 suite gagal, 2 lulus | Sebagian besar spec scaffold tidak menyediakan dependency/mocks service dan Prisma |
| `simrs-frontend: npm run build` | Berhasil | SPA dapat dikompilasi untuk build |
| `simrs-frontend: npm run lint` | Gagal: 34 error | Dominan `any` eksplisit dan aturan hook pada fungsi fetch di `useEffect` |

### Implikasi

Build yang berhasil membuktikan aplikasi secara sintaksis dapat dikemas, tetapi
tidak membuktikan keamanan, integritas transaksi, atau kesiapan operasional.
Kegagalan test dan lint harus dianggap sebagai utang kualitas aktif.

## 11. Risiko dan Temuan Utama

### Prioritas kritis

| Risiko | Bukti dari source | Dampak |
| --- | --- | --- |
| Endpoint klinis/keuangan tampak tanpa otorisasi | JWT dibuat pada Auth, tetapi tidak ditemukan guard; frontend tidak mengirim token | Pengguna yang dapat mencapai API berpotensi melakukan baca/tulis tanpa kontrol akses |
| Rahasia berada di source/dokumentasi | JWT secret tertulis pada `auth.module.ts`; credential/key database disebut dalam dokumentasi dan skrip | Kebocoran credential dan token signing secret |
| Integritas stok dan jurnal belum memadai | Pembayaran mengurangi baris stok pertama dengan `LIMIT 1`; riwayat menyimpan stok awal/akhir dan lokasi placeholder | Stok, batch, lokasi, dan audit keuangan dapat tidak akurat |

### Prioritas tinggi

| Risiko | Bukti dari source | Dampak |
| --- | --- | --- |
| Race condition nomor transaksi | Registrasi/resep mencari nomor terakhir lalu menambah satu; nota/jurnal memakai angka acak tiga digit | Benturan nomor pada penggunaan bersamaan |
| Input penting masih default/manual | Kode poli, dokter, NIP, no. rawat awal diset dalam komponen UI | Salah referensi tenaga medis/kunjungan dan data klinis tidak valid |
| Validasi input API minimal | Body controller tidak menggunakan DTO + validation pipe | Payload salah dapat menghasilkan error database atau mutasi tidak sah |
| Status modul dokumentasi tertinggal | README menyatakan Farmasi belum dimulai walaupun kode sudah ada | Keputusan pengembangan dan audit proyek berangkat dari informasi salah |

### Prioritas menengah

| Risiko | Bukti dari source | Dampak |
| --- | --- | --- |
| API URL dan CORS untuk development | URL `localhost:3000` berulang dan CORS global | Konfigurasi deployment dan kebijakan origin belum jelas |
| Testing otomatis tidak efektif | Unit test gagal karena dependency tidak disiapkan; e2e masih scaffold dasar | Regresi alur pelayanan tidak terdeteksi |
| Repository memuat artefak lokal | `simulation/venv/`, build output, serta file data uji ditemukan | Ukuran repository dan kebersihan distribusi terganggu |

## 12. Penilaian Kesiapan

| Dimensi | Penilaian | Alasan |
| --- | --- | --- |
| Kejelasan visi dan arsitektur integrasi | Cukup kuat | Prinsip database bersama dan workflow simulasi terdokumentasi |
| Cakupan functional prototype | Luas | Alur dari login sampai kasir tersedia dalam source |
| Kesiapan demonstrasi lokal | Menengah | Backend dan frontend dapat dibangun; kebutuhan DB tetap harus tersedia |
| Kesiapan pilot dengan data sensitif | Rendah | Otorisasi, rahasia, input default, dan integritas transaksi belum selesai |
| Kesiapan produksi | Belum siap | Memerlukan hardening keamanan, transaksi, test, konfigurasi, dan audit data |

## 13. Rekomendasi Prioritas Implementasi

### Fase 1: Keamanan dan kontrol akses

1. Pindahkan seluruh secret dan konfigurasi koneksi ke environment variable; rotasi
   nilai yang pernah tertulis di source atau dokumentasi.
2. Tambahkan strategi JWT/guard NestJS dan otorisasi berbasis peran untuk endpoint
   klinis, farmasi, bed, dan keuangan.
3. Tambahkan route protection frontend dan client API yang otomatis menyertakan
   token serta menangani sesi kedaluwarsa.

### Fase 2: Integritas transaksi dan data

1. Terapkan DTO, validasi request, exception mapping, dan audit trail pada API
   mutasi.
2. Benahi pembentukan nomor rawat, nomor resep, nota, dan jurnal agar aman terhadap
   concurrency dan mengikuti aturan SIMRS Dummy.
3. Validasi serta implementasikan mutasi stok berdasarkan gudang, batch, faktur,
   stok aktual, dan ketersediaan kuantitas; hilangkan placeholder audit.
4. Uji jurnal pembayaran terhadap rekening yang sah dan aturan akuntansi rumah
   sakit.

### Fase 3: Penyelesaian produk operasional

1. Ganti default poli, dokter, petugas, dan kunjungan dengan pilihan master data
   serta konteks pengguna login.
2. Hubungkan dashboard dengan API agregasi yang benar.
3. Satukan konvensi prefix API dan konfigurasi base URL berbasis environment.
4. Tambahkan navigasi, form feedback, loading state, error state, dan pembatasan
   akses layar sesuai peran.

### Fase 4: Quality gate dan rilis

1. Perbaiki unit test dengan mock Prisma/dependency dan tambahkan test service pada
   transaksi kritis.
2. Tambahkan integration/e2e test pada database uji terisolasi untuk registrasi,
   SOAP, resep, stok, dan pembayaran.
3. Jadikan build, lint, test, dan validasi schema sebagai quality gate CI.
4. Bersihkan artefak lokal serta hilangkan credential/data sensitif dari version
   control sebelum distribusi atau deployment.

## 14. Definisi Selesai untuk Pilot

Pilot operasional hanya layak dipertimbangkan setelah kriteria berikut terpenuhi:

- Endpoint mutasi terlindungi JWT dan role permission.
- Tidak ada secret atau credential aktif tersimpan dalam source/dokumentasi.
- Seluruh pemilihan pasien, kunjungan, dokter, petugas, unit, dan gudang berasal
  dari data valid, bukan nilai dummy.
- Transaksi resep/pembayaran/stok/jurnal lulus skenario sukses, gagal, rollback,
  stok tidak cukup, serta eksekusi bersamaan pada database uji.
- Build, lint, unit test, dan e2e alur kritis lulus secara otomatis.
- Prosedur backup, audit, rollback operasional, serta kompatibilitas SIMRS Dummy
  desktop telah ditandatangani pemilik proses rumah sakit.

## 15. Referensi Source Utama

| Referensi | Fungsi dalam analisis |
| --- | --- |
| `README.md` | Visi, aturan kompatibilitas database, dan roadmap awal |
| `simrs-backend/src/app.module.ts` | Daftar modul backend terpasang |
| `simrs-backend/prisma/schema.prisma` | Pemetaan domain data SIMRS Dummy |
| `simrs-backend/src/auth/` | Login dan konfigurasi JWT |
| `simrs-backend/src/registration/`, `queue/`, `bed/` | Alur pasien, antrean, admisi |
| `simrs-backend/src/rme/` | SOAP, CPPT, dan ICD-10 |
| `simrs-backend/src/farmasi/` | Obat, stok, resep dan racikan |
| `simrs-backend/src/kasir/` | Tagihan, bayar, stok, dan jurnal |
| `simrs-frontend/src/App.tsx` dan `src/pages/` | Permukaan pengguna dan integrasi API |
| `simulation/*.py` | Bukti pendekatan validasi database per modul |

---

Dokumen ini harus diperbarui ketika mekanisme keamanan, status test, alur
transaksi, atau cakupan modul berubah. Klaim implementasi di dalamnya mengacu
pada source yang tersedia pada tanggal analisis, bukan pada rencana yang belum
direalisasikan.
