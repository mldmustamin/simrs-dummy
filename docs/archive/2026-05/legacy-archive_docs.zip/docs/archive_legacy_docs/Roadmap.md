# Roadmap: Web App SIMRS Dummy (Pengganti 100%)

Dokumen ini memaparkan peta jalan (*roadmap*) jangka panjang untuk membangun **Aplikasi Web Murni (Full Web App)** yang akan menggantikan secara total aplikasi Java Desktop SIMRS Dummy, dengan hanya mempertahankan *database* bawaannya (`sik.sql`).

## 🎯 Visi & Objektif
- **100% Web Based:** Membuang total ketergantungan pada Java. Semua instalasi dan pemeliharaan cukup dilakukan di satu server Web.
- **Aksesibilitas Universal:** Dapat diakses dari *browser* apa pun (PC, Tablet, Smartphone) oleh dokter, perawat, dan staf manajemen.
- **Transisi Data Mulus:** Menggunakan *database* MySQL SIMRS Dummy (`sik`) lama sehingga ribuan data pasien yang sudah ada tidak perlu dipindah atau dimodifikasi strukturnya.

---

## 🛠️ Tumpukan Teknologi (Pure Web Stack)
- **Framework Utama:** Next.js (React) + Node.js
- **Bahasa:** TypeScript
- **Styling:** Tailwind CSS + Shadcn UI (Antarmuka Medis Premium & Cepat)
- **Database Connection:** Prisma ORM (Introspeksi skema database `sik` secara otomatis)

---

## 📅 Fase Implementasi Total

### Phase 1: Fondasi & Infrastruktur (Target: Bulan 1)
- [ ] Setup Server Web lokal & Konfigurasi *Database* MySQL `sik`.
- [ ] Pembuatan kerangka proyek `simrs-web` (Next.js).
- [ ] *Database Introspection*: Memetakan seluruh ratusan tabel SIMRS Dummy ke Prisma ORM.
- [ ] Pembuatan API otentikasi sentral (Sistem Login Web menggunakan tabel *user/pegawai*).

### Phase 2: Modul Esensial Front-Office & Dokter (Target: Bulan 2-3)
- [ ] Modul **Pendaftaran (Front Office)**: Registrasi Pasien Baru & Lama, Pembuatan SEP BPJS.
- [ ] Modul **Rekam Medis Jalan (Ralan)**: Halaman khusus dokter untuk input Anamnesa, Diagnosa (ICD), dan E-Resep.
- [ ] Modul **Antrean Poli**: Tampilan *dashboard* antrean real-time.

### Phase 3: Penunjang Medis & Keuangan (Target: Bulan 4-5)
- [ ] Modul **Apotek (Farmasi)**: Validasi resep, penyerahan obat, manajemen stok.
- [ ] Modul **Laboratorium & Radiologi**: Input hasil pemeriksaan dan pencetakan PDF.
- [ ] Modul **Kasir / Billing**: Penyatuan biaya pendaftaran, obat, dan tindakan. Cetak *invoice*.

### Phase 4: Perawatan Inap & EWS (Target: Bulan 6-7)
- [ ] Modul **Rawat Inap (Ranap)**: Manajemen Kamar/Bed, status ketersediaan.
- [ ] Modul **Keperawatan (CPPT)**: Catatan Terintegrasi dan *Early Warning System (EWS)*.

### Phase 5: Back-Office & Finalisasi (Target: Bulan 8+)
- [ ] Modul **Keuangan Lanjutan, Penggajian, dan Akuntansi**.
- [ ] Modul **Inventaris & Aset Logistik**.
- [ ] **Sunset (Penutupan)** total aplikasi Java Desktop (semua operasional telah berjalan 100% via Web App).
