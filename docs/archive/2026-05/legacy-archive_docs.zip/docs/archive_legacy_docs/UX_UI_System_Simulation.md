# Prompt Simulasi UX/UI (Full System Aladin SIMRS)

Dokumen ini berisi panduan dan *prompt* lengkap untuk melakukan pengujian, *prototyping*, dan simulasi *user interface* (UI) serta *user experience* (UX) untuk **seluruh ekosistem Aladin SIMRS**. 

Anda dapat menyalin *prompt* di bawah ini dan menggunakannya di *AI UI Generator* seperti **v0.dev**, **Claude Artifacts**, atau **Google IDX / Project IDX** untuk melihat wujud visual aplikasi tanpa harus melakukan *coding* manual.

---

## 📋 PROMPT UTAMA (MASTER PROMPT)
*Salin teks di bawah ini untuk meng-generate kerangka aplikasi utama (Shell & Dashboard).*

```text
Buatkan antarmuka web modern Single Page Application (SPA) menggunakan React dan TailwindCSS untuk "Aladin SIMRS" (Hospital Information System). 

[DESIGN SYSTEM & AESTHETICS]
- Tema: Dark Mode premium nan mewah dengan gaya "Glassmorphism" (latar belakang gelap/hitam dengan kartu semi-transparan, backdrop-blur).
- Typography: Gunakan font Sans-serif modern (seperti Inter atau Plus Jakarta Sans).
- Warna Utama: Gradient Teal ke Cyan untuk primary (Aksen Medis modern), Emerald untuk aksi sukses, Amber untuk peringatan, dan Rose/Red untuk error/danger.
- Ikonografi: Gunakan `lucide-react` untuk semua icon.
- Interaksi: Tambahkan micro-animation (hover scale tipis, glow effect pada border aktif, dan transisi smooth antar halaman).

[LAYOUT UTAMA (APP SHELL)]
1. Sidebar Kiri (Navigasi): 
   - Logo "Aladin SIMRS" (Teks gradient).
   - Menu berderet: Dashboard, Pendaftaran, Antrean, Poli/CPPT, Farmasi & Apotek, Kasir, Manajemen Bed.
   - Menu yang sedang aktif memiliki latar gradient tipis dengan border kiri tebal warna Teal.
2. Header Atas: 
   - Global Search Bar ("Cari pasien, no resep, dokter...").
   - Notification Bell (dengan dot merah untuk indikator).
   - Profile User ("Admin Aladin").
3. Main Content Area (Tengah - Kanan): Tempat menampilkan konten per halaman.

[HALAMAN DASHBOARD (DEFAULT VIEW)]
- Tampilkan 4 Kartu Statistik Utama di paling atas:
  a. "Total Pasien Hari Ini" (Ikon Users, angka besar: 342, persentase naik hijau +12%).
  b. "Poli Sedang Aktif" (Ikon Stethoscope, angka: 8).
  c. "Antrean Farmasi" (Ikon Pill, angka: 15, teks merah "5 Perlu Validasi").
  d. "Pendapatan Kasir" (Ikon Wallet, angka: Rp 45.2M).
- Di bawahnya, buat 2 kolom (Grid):
  - Kolom Kiri: "Akses Modul Cepat" (Berupa tombol-tombol grid berwarna-warni yang estetik untuk navigasi instan).
  - Kolom Kanan: "Grafik Kunjungan Hari Ini" (Gunakan placeholder UI grafik bar melengkung yang cantik).

Berikan kesan aplikasi ini sangat responsif, canggih, futuristik, namun ramah untuk pengguna rumah sakit (Dokter, Perawat, Kasir).
```

---

## 🏥 PROMPT MODUL PENDAFTARAN & ANTREAN
*Gunakan ini untuk mensimulasikan layar admisi pasien.*

```text
Lanjutkan desain Aladin SIMRS sebelumnya. Sekarang tampilkan layar "Modul Pendaftaran & Antrean Pasien". 

Layout:
- Bagi layar menjadi 2 bagian utama (Kiri: Form Input, Kanan: Live Antrean).
- Form Input Pendaftaran:
  - Gunakan input field yang estetik (background hitam transparan, border glow saat di-klik).
  - Field: "No Rekam Medis (Jika Pasien Lama)", "Nama Pasien Baru", "Pilih Poliklinik (Dropdown)", "Pilih Dokter (Dropdown)", "Jenis Bayar (BPJS / Umum / Asuransi)".
  - Tombol Submit besar: "Daftarkan Pasien & Cetak SEP".
- Live Antrean (Kolom Kanan):
  - Tampilkan list kartu pasien yang sedang mengantre di pendaftaran. 
  - Tiap kartu menunjukkan nomor antrean besar (Misal: A-012), nama poli yang dituju, dan tombol "Panggil Pasien".
```

---

## 🩺 PROMPT MODUL CPPT & RME (DOKTER)
*Gunakan ini untuk mensimulasikan layar kerja Dokter di Poliklinik.*

```text
Lanjutkan desain Aladin SIMRS. Sekarang buatkan antarmuka untuk "Rekam Medis Elektronik (CPPT) - Tampilan Dokter".

Layout:
- Bagian Atas: Profil singkat Pasien (Nama, Umur, Alergi - highlight merah jika ada alergi).
- Layar dibagi dengan sistem TAB navigasi horizontal yang mulus:
  1. Tab "SOAP (Subjektif, Objektif, Asesmen, Plan)": Terdapat text area kaya fitur untuk dokter mengetik hasil diagnosa, dropdown pencarian ICD-10 (Beri contoh chip "A09 - Diarrhoea"), dan input tanda-tanda vital.
  2. Tab "Tindakan Medis": Tabel daftar tindakan yang diberikan.
  3. Tab "E-Resep Obat":
     - Form pencarian obat dengan autocomplete.
     - Terdapat dua area: "Obat Jadi" dan "Bungkus Racikan".
     - Keranjang E-Resep yang melayang di sebelah kanan.
- Berikan tombol "Simpan CPPT & Teruskan ke Farmasi/Kasir" di pojok kanan bawah.
```

---

## 💊 PROMPT MODUL FARMASI & APOTEK (SUPERVISOR OVERRIDE)
*Gunakan ini untuk mensimulasikan sistem keamanan anti-fraud pada Farmasi.*

```text
Buatkan layar "Validasi E-Resep & Apotek" untuk Aladin SIMRS. 

Skenario Interaktif (Wajib buat seolah-olah terjadi):
1. Tampilkan Grid kartu "Antrean Resep Masuk" dari dokter.
2. Saat Apoteker mengklik tombol "Validasi & Serahkan Obat" pada salah satu pasien, buat efek layar utama menjadi blur (Backdrop blur) dan munculkan modal pop-up darurat ke tengah layar.
3. Desain Modal Pop-up:
   - Tema peringatan kritis (Aksen border merah menyala).
   - Judul: "Peringatan: Stok Tidak Cukup!".
   - Detail: "Paracetamol (Tersedia: 2 / Dibutuhkan: 10)".
   - Fitur Otorisasi Berjenjang: Terdapat input field rahasia berlabel "Masukkan PIN Supervisor untuk Override (Paksa Stok Minus)".
   - Tombol "Batalkan" dan "Paksa Validasi (Bahaya)".
   - Tambahkan keterangan kecil: "Aksi ini akan mencatat log aktivitas ke sistem sebagai audit trail."
```

---

## 💳 PROMPT MODUL KASIR (BILLING TERINTEGRASI)
*Gunakan ini untuk mensimulasikan layar Kasir.*

```text
Buatkan layar "Kasir Sentral" untuk Aladin SIMRS.

- Sebelah Kiri: Daftar Pasien Belum Bayar (List vertikal dengan badge status warna kuning "Menunggu Pembayaran").
- Sebelah Kanan (Area Nota Pembayaran):
  - Tampilkan desain struk tagihan digital yang rapi dan detail, terbagi atas 3 seksi:
    1. Biaya Pendaftaran & Karcis.
    2. Biaya Tindakan Dokter (Contoh: Nebulizer, Jahit Luka).
    3. Biaya Farmasi & Obat (Berdasarkan data E-Resep yang telah divalidasi Apoteker).
  - Di bagian bawah, tampilkan "Grand Total" dengan font sangat besar dan menyolok (warna Emerald).
  - Terdapat input field "Jumlah Uang Diterima" yang otomatis menghitung "Kembalian".
  - Tombol aksi: "Proses Pembayaran & Generate Jurnal Akuntansi".
```
