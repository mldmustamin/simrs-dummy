# Dosa Penyederhanaan & Hutang Teknis SIMRS-Web (The Technical Debt Ledger)

Dokumen ini memuat **seluruh** titik penyederhanaan (simplifikasi), jalan pintas (*shortcuts*), dan bypass logika yang telah dilakukan sepanjang fase pengembangan MVP (Minimum Viable Product). 

Daftar ini diurutkan dari level **Paling Ringan (Kosmetik/UI)** hingga level **Paling Krusial (Keuangan & Hukum)**. Ini adalah peta jalan mutlak bagi *Developer* untuk melakukan refaktor sebelum aplikasi ini menyentuh server *Production*.

---

## 🟢 Level 1: Teringan (UI/UX & Kosmetik)
Dampak: Tidak merusak database, hanya mengurangi kenyamanan atau performa pada skala besar.

1.  **Tidak Ada Server-Side Pagination:** Pada dasbor Rekam Medis, Antrean, dan Farmasi, kueri database menarik seluruh data (atau di-limit manual di backend) lalu disaring di Frontend. Saat data mencapai jutaan baris, aplikasi Web akan *freeze* atau kehabisan memori (*Out of Memory*).
2.  **Hardcode Nilai Default:** Di beberapa komponen React (seperti `Farmasi.tsx`), nomor rawat dan kode dokter awal di-*hardcode* untuk kemudahan *testing*, belum 100% dinamis terikat ke sesi login pengguna saat itu.
3.  **Error Handling Primitif:** Penanganan *error* saat validasi (misalnya stok kosong) masih menggunakan `alert()` bawaan browser atau teks statis, belum menggunakan sistem notifikasi *Toast* atau *Modal* yang rapi.
4.  **Absennya DTO Validation:** Backend NestJS tidak menggunakan *Class Validator* (Zod/Joi) secara ketat untuk menyaring payload JSON yang masuk dari Frontend, sehingga rentan terhadap injeksi data tipe yang salah.

---

## 🟡 Level 2: Menengah (Operasional Dasar & Edge Cases)
Dampak: Mengacaukan alur kerja staf, tetapi belum sampai merusak laporan keuangan atau hukum.

5.  **Bypass Tabel `hak_akses` (Tanpa RBAC):** 
    - Autentikasi JWT kita sangat buta. Kita sama sekali tidak membaca hak akses asli dari SIMRS Dummy. Saat ini, seorang Apoteker bisa dengan mudah membuka menu Kasir atau sebaliknya. 
6.  **Otentikasi Password Bypass:** 
    - Kita belum mereplikasi algoritma *hashing* password spesifik yang digunakan oleh SIMRS Dummy Desktop (AES/SHA/MD5), sehingga *auth* saat ini masih menggunakan metode komparasi sederhana.
7.  **Bypass Jadwal Dokter (`jadwal`):** 
    - Modul pendaftaran mengasumsikan semua dokter tersedia setiap saat. Kenyataannya, SIMRS Dummy mengunci pendaftaran jika hari dan jam tersebut di luar jadwal praktek sang dokter.
8.  **Manajemen Rawat Inap Bisu:** 
    - Modul Dasbor Bed (Modul 2) hanya membaca status pasif dari tabel `kamar`. Logika transaksional yang kompleks seperti *Pindah Kamar*, *Titip Inap*, atau *Pulang Paksa* (yang melibatkan tabel `kamar_inap`) tidak disentuh sama sekali.
9.  **Simplifikasi Kalkulasi Tarif Tindakan Dokter:** 
    - Biaya di `rawat_jl_dr` dihitung secara pukul rata (*Flat*). Padahal di sistem asli, tarif akan dibedakan berdasarkan Kelas Pasien (VIP, Kelas 1, dsb) atau Jenis Penjamin (Umum vs Asuransi). Kita juga menggabungkan Jasa Medis, KSO, dan Manajemen menjadi satu gelondongan harga kasar.

---

## 🔴 Level 3: Krusial (Keuangan, Inventory, Keamanan & Legal)
Dampak: Rumah Sakit rugi finansial secara masif, audit akuntansi berantakan, dan klaim BPJS ditolak.

10. **Bypass Algoritma Mutasi Stok Gudang (FIFO/LIFO):** 
    - *The Phantom Stock:* Modul E-Resep Farmasi kita tidak pernah benar-benar memotong fisik stok obat di tabel `gudangbarang`. Kita sama sekali tidak menyentuh tabel `riwayat_barang_medis`. Jika Web ini dipakai, jumlah stok di komputer akan selisih ratusan hingga ribuan obat dibandingkan stok fisik di rak gudang nyata.
11. **Menghilangkan Komponen Harga Embalase & Tuslah:** 
    - Harga obat di Web kita dihitung murni dari harga pokok (`ralan`). Kita membuang biaya Embalase (plastik/kertas/botol) dan Tuslah (Jasa Apoteker). Rumah Sakit akan kehilangan salah satu sumber pendapatan terbesarnya di unit Farmasi.
12. **Bypass Kueri BPJS V-Claim (Tanpa Penerbitan SEP):** 
    - Saat mendaftarkan pasien BPJS, SIMRS Dummy yang asli wajib melakukan *bridging* ke server BPJS untuk menerbitkan SEP (Surat Eligibilitas Peserta). Web kita tidak melakukan itu. Klaim puluhan juta per pasien bisa hangus karena dokumen BPJS tidak terbit secara sistem.
13. **Pengabaian Standar Kodifikasi WHO (ICD-10 & ICD-9):** 
    - Di modul CPPT, dokter di Web kita menulis keluhan layaknya *chat* teks bebas (*Free-Text*). Padahal, BPJS mensyaratkan setiap diagnosa harus diikat ke tabel `diagnosa_pasien` menggunakan kode ICD-10 resmi agar tarif paket INA-CBG bisa keluar.
14. **Penghapusan Jurnal Akuntansi (Buku Besar Buta):** 
    - **DOSA TERBESAR.** Kasir di Modul 5 menekan tombol "Bayar" dan berhasil mencetak Nota. Namun, uang tersebut tidak pernah dibukukan ke dalam tabel `jurnal` atau `detailjurnal`. 
    - Di SIMRS Dummy asli, Rp500.000 akan dipecah secara akuntansi: *Debit (Kas Rp500rb)* -> *Kredit (Pendapatan Jasa Rp200rb, Pendapatan Obat Rp300rb)*. Sistem kita **NOL** pencatatan debit-kredit. Uang ratusan juta rupiah yang dibayar via Web tidak akan terbaca di Laporan Laba Rugi dan Neraca RS.
15. **Mengabaikan Sistem Piutang & Uang Muka:** 
    - Tidak semua tagihan lunas dengan uang tunai. Pasien Asuransi meninggalkan "Piutang" untuk diklaim bulan depan. Sistem Kasir kita berasumsi semua pembayaran adalah uang tunai keras (*Cash Lunas*). Kita sama sekali tidak membedah logika `piutang_pasien`.
