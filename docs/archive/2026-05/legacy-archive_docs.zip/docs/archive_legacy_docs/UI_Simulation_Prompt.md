# Prompt Simulasi UI (Google IDX / v0 / Claude Artifacts)

Jika Anda ingin melakukan simulasi atau melihat demo *prototype* antarmuka (UI) dari Modul Apotek secara terpisah di platform desain (seperti v0.dev, Claude, atau Google IDX / Project IDX / Stitch), Anda bisa me-*copy-paste* prompt di bawah ini ke platform tersebut:

---

**Salin teks di bawah garis ini:**

```text
Buatkan antarmuka web modern menggunakan React dan TailwindCSS untuk "Modul Apotek - Validasi Resep & Override Stok". 
Gunakan desain yang sangat premium: palet warna gelap (Dark Mode) dipadukan dengan aksen Teal dan Emerald (Glassmorphism). Gunakan ikon dari `lucide-react`.

1. **Header & Navigation**:
   - Tampilkan judul "Farmasi & Apotek" dengan gradient text.
   - Tombol "Refresh Antrean".

2. **Daftar Antrean Resep (Grid Layout)**:
   - Tampilkan minimal 3 kartu resep pasien yang sedang antre (nama pasien, no rawat, waktu masuk).
   - Di dalam setiap kartu, tunjukkan rincian obat yang dipesan (misal: 10x Paracetamol, 3x1 Hari).
   - Terdapat tombol besar berwarna Teal: "Validasi & Serahkan".

3. **Interaksi Modal (Penting: Fitur Stok Minus/Fraud Prevention)**:
   - Buat sebuah state dimana jika tombol "Validasi" diklik pada pasien pertama, layar akan meredup (backdrop blur) dan memunculkan **Modal Peringatan**.
   - **Desain Modal Peringatan**:
     - Warna border merah dengan aksen bahaya.
     - Teks: "Peringatan: Stok Tidak Cukup!".
     - Tampilkan list obat yang kurang (misal: "Paracetamol - Tersedia: 0 / Dibutuhkan: 10").
     - Terdapat input PIN: "Masukkan PIN Supervisor (Override)".
     - Tombol "Batal" dan "Paksa Validasi".
   - Jika PIN diisi dan "Paksa Validasi" ditekan, tampilkan toast notification hijau "Validasi Berhasil! Stok dipaksa menjadi minus dan log dicatat."

Pastikan desainnya sangat futuristik, menggunakan animasi ringan (hover effects), dan UI yang fungsional layaknya aplikasi HIS (Hospital Information System) kelas atas.
```

---

*File ini disediakan khusus bagi Anda untuk menguji ide desain secara visual sebelum disetujui, sesuai dengan prinsip "Anti Halu" kita.*
