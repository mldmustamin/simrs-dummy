# Penutupan Modul 0: Infrastruktur & Autentikasi Selesai 🎉

Kita telah berhasil menyelesaikan pondasi utama aplikasi SIMRS-Web (Modul 0) dengan memadukan ekosistem modern (NestJS + React) dan mempertahankan warisan logika dari database SIMRS Dummy lama. 

Semua langkah telah divalidasi melalui **Simulasi Notebook**, menghasilkan kode yang anti-impulsif dan 100% *works* pada data aktual!

## Apa saja yang telah dibangun?

1. **Scaffolding Proyek Selesai:**
   - **Frontend:** React + Vite + Tailwind CSS v4 (Glassmorphism Mode). Telah dikonfigurasi dengan *React Router* dan tampilan modern.
   - **Backend:** NestJS terhubung ke MariaDB (SIMRS Dummy) menggunakan Prisma ORM. 

2. **Simulasi Notebook Berhasil:**
   - Skrip Python (`auth_simulation.py`) mendemonstrasikan ekstraksi akun dari MariaDB dan dekripsi *password* menggunakan Native Database Encryptions (AES).

3. **Integrasi Autentikasi SIMRS Dummy (Real-Time):**
   - **Metode Autentikasi SIMRS Dummy Diterapkan:**
     - Akun dan kata sandi pada tabel `admin` diproses melalui `AES_DECRYPT`.
     - Kunci dekripsi disediakan melalui environment variable lokal dan tidak dicatat dalam repository.
   - API Login di `AuthController` menggunakan raw SQL Prisma (`$queryRaw`) untuk mengeksekusi `AES_DECRYPT` secara *native*, mencocokkan password, dan kemudian meng- *generate* Token Akses **(JWT)** yang berlaku selama 8 jam.
   
4. **Alur UI Tersambung (Frontend ➔ Backend):**
   - Form *Login* di aplikasi Frontend kini menembak API `POST http://localhost:3000/api/auth/login`.
   - Token disimpan secara aman dan pengguna langsung diarahkan ke `/dashboard`.

---

> [!TIP]
> **Cara Menguji Modul 0:**
> 1. Buka terminal 1: Masuk ke folder `/simrs-backend` lalu jalankan `npm run start:dev`.
> 2. Buka terminal 2: Masuk ke folder `/simrs-frontend` lalu jalankan `npm run dev`.
> 3. Buka browser, akses halaman Login, lalu gunakan akun uji yang disediakan administrator lingkungan lokal.
> 4. Login yang berhasil akan menghasilkan JWT token dan membuktikan koneksi aplikasi dengan database pengujian.

## Penutupan Modul 1: Pencarian Pasien & Registrasi (Front Office) 🏥

Setelah infrastruktur utama kokoh, kita berhasil menyelesaikan fitur inti registrasi rawat jalan tanpa mengorbankan integritas data SIMRS Dummy!

### 1. Mapping Skema Prisma (Anti-Silo)
Alih-alih mengintrospeksi ribuan tabel, kita mengukir skema Prisma secara modular dengan menambahkan entitas:
- `pasien` (Data Demografi)
- `penjab` (Penanggung Jawab / Asuransi)
- `reg_periksa` (Kunjungan / Registrasi)
- `poliklinik` & `dokter`

### 2. Validasi Simulasi Notebook Sukses ✅
Skrip Python `modul1_patient.py` sukses mengekstrak data dari MariaDB dan mensimulasikan pencarian pasien menggunakan kueri `LIKE` dan operasi `JOIN`, serta men- *generate* format nomor rawat SIMRS Dummy (`YYYY/MM/DD/NoUrut`) sebelum melakukan *Dry-Run* insersi ke `reg_periksa`.

### 3. Eksekusi React & NestJS 🚀
- **Backend (`PatientService` & `RegistrationService`):** Menyediakan API untuk mencari pasien berdasarkan NIK atau Nama dalam hitungan milidetik, serta API pendaftaran yang secara otomatis menghitung *No Rawat* dan *No Antrean* berdasarkan data hari ini.
- **Frontend (`Registration.tsx`):** Layar pencarian *real-time* dengan visualisasi minimalis. Begitu pasien diklik, sistem langsung menyajikan form konfirmasi pendaftaran.

---

> [!TIP]
> **Cara Menguji Modul 1:**
> 1. Pastikan backend (`npm run start:dev`) dan frontend (`npm run dev`) sedang berjalan.
> 2. Kunjungi `http://localhost:5173/registration` di *browser*.
> 3. Ketik nama pasien (misal: "a") lalu klik **Cari Data SIMRS Dummy**.
> 4. Anda akan melihat data ditarik seketika dari MariaDB lama!
> 5. Klik pada salah satu pasien, lalu tekan **Simpan ke Reg Periksa (SIMRS Dummy)**. Registrasi baru akan terbentuk seketika tanpa mengubah kode SIMRS Dummy lama.

## Penutupan Modul 2: Pendaftaran Antrean & Manajemen Rawat Inap (Bed Management) 🛏️

Fitur *Front Office* dan admisi pasien kini semakin lengkap!

### 1. Pembuktian Kendala Relasi (Foreign Key)
Dalam sesi Python Notebook (`modul2_queue_bed.py`), kita mencoba meregistrasi pasien secara "Direct Admission" ke kamar rawat inap (tabel `kamar_inap`). MySQL MariaDB memblokir transaksi tersebut karena kendala relasi (Foreign Key) mengharuskan pasien memiliki nomor rawat (`no_rawat`) di tabel pendaftaran (`reg_periksa`) terlebih dahulu.
Hal ini mengonfirmasi bahwa alur SIMRS Dummy mensyaratkan setiap pasien terdaftar di poli/IGD sebelum bisa dimutasi ke ranap.

### 2. Live Antrean Poliklinik
- Dibuat `QueueService` di NestJS yang menarik daftar pasien berstatus 'Belum' dari `reg_periksa` secara otomatis (hanya untuk tanggal hari ini).
- Halaman Frontend `/queues` memvisualisasikan data tersebut secara *real-time* (polling setiap 5 detik), memberikan UI mirip layar panggil rumah sakit.

### 3. Bed Management (Admisi Rawat Inap)
- Dibuat `BedService` yang mampu menarik data ketersediaan tempat tidur `KOSONG` dari tabel `kamar`.
- Terdapat fungsi mutasi *Transactional*: Saat pengguna menekan "Tempatkan Pasien" di Frontend (`/beds`), sistem meng-*insert* data ke `kamar_inap` lalu mengubah status `kamar` menjadi `ISI` dalam satu transaksi atomik.

> [!TIP]
> **Cara Menguji Modul 2:**
> 1. Kunjungi **`http://localhost:5173/queues`** untuk melihat daftar antrean hari ini yang ditarik *live* dari SIMRS Dummy.
> 2. Kunjungi **`http://localhost:5173/beds`** untuk memonitor sisa kasur kosong. Masukkan `No Rawat` (yang valid di `reg_periksa` hari ini) dan klik *Tempatkan Pasien* untuk mensimulasikan admisi!

---

## Penutupan Modul 3: Rekam Medis Elektronik (RME / CPPT) 📋

Modul inti klinis telah berhasil diimplementasikan! Dokter dan perawat kini bisa menggunakan antarmuka web untuk mencatat SOAP dan diagnosa pasien.

### 1. Simulasi Python Berhasil (6/6 Skenario ✅)
Skrip `modul3_rme_cppt.py` memvalidasi 6 skenario secara nyata:
- **Skenario 1-2:** Menarik riwayat SOAP rawat jalan (`pemeriksaan_ralan`) dan rawat inap (`pemeriksaan_ranap`), menampilkan data SOAP pasien seperti ROBY ALAMSYAH (panas beberapa hari) dan ADI KAZAMA (rawat inap).
- **Skenario 3:** Menarik diagnosa ICD-10 yang sudah tercatat (I50.0 Congestive heart failure, K30 Dyspepsia, A01.0 Typhoid fever, dll).
- **Skenario 4:** Menarik riwayat tindakan dokter rawat jalan (Pemeriksaan Poli Spesialis Rp250.000, dll).
- **Skenario 5:** INSERT SOAP baru → awalnya gagal karena **FK Constraint** `nip` → `pegawai.nik`. Diperbaiki dengan menggunakan NIP valid (`D0000002` = dr. Aisyah). Setelah fix, berhasil + rollback.
- **Skenario 6:** INSERT diagnosa J02.9 (Acute pharyngitis) → berhasil + rollback.

### 2. Prisma Schema (7 Model Baru)
Ditambahkan model: `penyakit` (40.802 kode ICD-10!), `pemeriksaan_ralan`, `pemeriksaan_ranap`, `diagnosa_pasien`, `jns_perawatan` (1.287 jenis tindakan), `rawat_jl_dr`. Model `pegawai` yang sudah ada diperkaya dengan relasi balik ke pemeriksaan.

### 3. Backend NestJS (`RmeService`)
API Endpoints:
- `GET /api/rme/cppt/:rm` → Riwayat SOAP ralan + ranap per pasien
- `POST /api/rme/soap` → Input SOAP baru (langsung masuk ke tabel `pemeriksaan_ralan` SIMRS Dummy)
- `GET /api/rme/diagnoses/:rm` → Riwayat diagnosa ICD-10
- `POST /api/rme/diagnosis` → Tambah diagnosa ICD-10
- `GET /api/rme/icd10?q=keyword` → Pencarian 40.802 kode ICD-10

### 4. Frontend (`MedicalRecord.tsx`)
Antarmuka terdiri dari:
- **Tab CPPT:** Menampilkan riwayat SOAP rawat jalan (border indigo) dan rawat inap (border amber) secara kronologis, lengkap dengan tanda vital.
- **Tab Diagnosa ICD-10:** Daftar diagnosa yang sudah tercatat + pencarian kode ICD-10 interaktif dengan tombol "Tambah".
- **Form SOAP (Kolom Kanan):** Panel sticky untuk menginput Subjective, Objective, Assessment, Plan, dan tanda vital.

> [!TIP]
> **Cara Menguji Modul 3:**
> 1. Kunjungi **`http://localhost:5173/rme`**
> 2. Masukkan No RM pasien (misal: salah satu RM dari database) lalu klik **Lihat Riwayat**
> 3. Anda akan melihat riwayat SOAP dan diagnosa dari database SIMRS Dummy asli
> 4. Beralih ke tab **Diagnosa ICD-10**, cari "typhoid" → akan muncul kode dari 40.802 entri ICD-10
> 5. Isi form SOAP di kolom kanan, pastikan No Rawat valid, lalu klik **Simpan SOAP ke SIMRS Dummy**

---

## Penutupan Modul 4: Farmasi & E-Resep 💊

Modul akhir untuk siklus pelayanan rawat jalan telah selesai dibangun!

### 1. Simulasi Python Master Obat & Resep
Skrip `modul4_farmasi.py` berhasil:
- Mengekstrak data dari `databarang` (Master Obat).
- Mengekstrak stok per bangsal dari tabel `gudangbarang`.
- Melakukan *Dry-Run* INSERT e-resep ke `resep_obat` dan `resep_dokter` tanpa merusak integritas sistem SIMRS Dummy.

### 2. Update Skema Prisma
Tabel `databarang`, `gudangbarang`, `resep_obat`, dan `resep_dokter` telah ditambahkan dan dihubungkan secara relasional dengan pendaftaran dan dokter di Prisma Schema.

### 3. Frontend Farmasi (Glassmorphism & Dinamis)
Halaman `/farmasi` dirancang secara estetis dengan pemisahan Tab (Obat Jadi vs Obat Racikan):
- **Pencarian Real-time:** Menemukan bahan/obat berdasarkan nama dalam database `databarang`.
- **Cek Stok Gudang:** Fitur modal interaktif untuk melihat stok gudang langsung dari sumber aslinya.
- **Keranjang E-Resep & Builder Racikan:** 
  - Mengatur obat jadi yang dipilih dan aturan pakai.
  - Fitur meracik *(Builder)*: Menamai bungkus racikan, menentukan metode (Puyer/Kapsul), memasukkan rasio takaran (P1/P2), lalu mengalkulasi fisik total obat yang dipotong.
  - Payload JSON akan di-submit dan membagi tabel ke `resep_dokter` atau `resep_dokter_racikan` dengan aman!

> [!TIP]
> **Cara Menguji Modul 4 (Obat Jadi & Racikan):**
> 1. Kunjungi **`http://localhost:5173/farmasi`**
> 2. Tab "Obat Jadi": Cari obat (mis: `paracetamol`) pada panel kiri, lalu klik **Cek Stok**. Klik **Pilih** untuk menambahkan ke keranjang.
> 3. Tab "Obat Racikan": Buat bungkus racikan (mis: Puyer Anak), atur *jml_dr* (10), cari bahan "Amoxicillin", lalu atur takaran P1/P2 (mis: 1/2). Fisik total (5) akan terkalkulasi. Klik **Simpan Racikan ke Keranjang**.
> 4. Klik **Kirim E-Resep** untuk menyimpan semua data ke MariaDB SIMRS Dummy.

**Semua target Modul 0 hingga Modul 4.1 (E-Resep Racikan) telah tercapai sepenuhnya tanpa mendisrupsi database SIMRS Dummy lama!** 🚀

### 4. Dasbor Kasir & Keuangan (Billing Terpadu)
Halaman `/kasir` dirancang secara estetis untuk menyatukan seluruh tagihan dari ujung ke ujung:
- **Agregasi Biaya Dinamis:** Menarik total harga dari Pendaftaran (`reg_periksa`), Tindakan Dokter (`rawat_jl_dr`), dan Obat (`detail_pemberian_obat`).
- **Simulasi On-the-Fly:** Jika ada pembatalan obat di detik-detik terakhir sebelum kasir menekan tombol bayar, tagihan otomatis ter-update karena kita menggunakan kalkulasi kueri langsung, bukan menyimpan *cache* di tabel statis.
- **Transaksi Pembayaran Transaksional:** Menggunakan metode `Prisma.$transaction` untuk menjamin pencetakan Nota (`nota_jalan`) dan pembaruan Status Lunas (`stts_bayar`) terjadi secara bersamaan untuk mencegah data bocor/korup jika server putus.

> [!TIP]
> **Cara Menguji Kasir (Modul 5):**
> 1. Buka **`http://localhost:5173/kasir`**
> 2. Masukkan Nomor Rawat pasien yang sudah melewati CPPT dan mendapat resep, misalnya: **`2026/02/25/000005`** lalu klik Cari.
> 3. Semua rincian akan tampil. Coba buka tabel *collapsible* untuk melihat rincian tindakan dan obat secara detail.
> 4. Masukkan **Nominal Uang Diterima**, lalu klik **Proses Pembayaran**.
> 5. Anda akan menerima Nomor Nota (Contoh: `RJ20260526...`) dan layar berubah menjadi status "LUNAS".
