# ⚖️ Perbandingan Ukuran: SIMRS-Web vs SIMRS Dummy (Asli)

Dokumen ini membandingkan proyek **SIMRS-Web** (hasil kerja kita) dengan **SIMRS Dummy** asli (repositori GitHub [`mas-elsimrs_dummy/SIMRS Dummy`](https://github.com/mas-elsimrs_dummy/SIMRS Dummy)).

---

## 📊 1. Perbandingan Ukuran Kasar (Raw Size)

### SIMRS Dummy Asli (GitHub API)

| Bahasa | Ukuran (Bytes) | Ukuran (MB) | Persentase |
|---|---:|---:|---:|
| **Java** | 116,835,304 | **111.4 MB** | 76.3% |
| JavaScript | 20,250,587 | 19.3 MB | 13.2% |
| PHP | 7,536,460 | 7.2 MB | 4.9% |
| HTML | 4,579,259 | 4.4 MB | 3.0% |
| CSS | 2,580,587 | 2.5 MB | 1.7% |
| Pascal | 1,142,548 | 1.1 MB | 0.7% |
| Lainnya (Hack, CoffeeScript, SCSS, Less) | ~494,687 | 0.5 MB | 0.3% |
| **TOTAL SOURCE CODE** | **153,419,432** | **~146.3 MB** | **100%** |

> [!NOTE]
> Angka di atas adalah **byte kode sumber murni** (tanpa binary/gambar/library) yang dilaporkan oleh GitHub Languages API. Ukuran repositori sesungguhnya (termasuk `.git` history, gambar, library Java `.jar`, dll) jauh lebih besar lagi.

### SIMRS-Web (Proyek Kita)

| Komponen | Ukuran Total | Ukuran Source Murni |
|---|---:|---:|
| **Backend** (`simrs-backend/`) | 337 MB | **260 KB** (src/ + schema) |
| **Frontend** (`simrs-frontend/`) | 214 MB | **144 KB** (src/) |
| **Simulation** (`simulation/`) | 437 MB | **680 KB** (scripts + SQL dump) |
| **Konfigurasi** (config files) | — | **32 KB** |
| **TOTAL dengan dependensi** | **988 MB** | — |
| **TOTAL source code murni** | — | **~1.3 MB** |

### Breakdown Ukuran "Bukan Kode Kita"

| Komponen | Ukuran | Penjelasan |
|---|---:|---|
| `node_modules/` (backend) | 334 MB | 727 package npm (NestJS, Prisma, dll) |
| `node_modules/` (frontend) | 213 MB | React, Vite, TailwindCSS, dll |
| `venv/` (simulation) | 436 MB | Python virtual environment |
| `schema-introspect.prisma` | 2.3 MB | Hasil introspeksi 1000+ tabel SIMRS Dummy (referensi) |
| `dist/` (compiled JS) | ~1 MB | Output build NestJS + Vite |
| `package-lock.json` (2 file) | ~496 KB | Lock file dependensi |

---

## 📏 2. Perbandingan Jumlah Baris Kode (Lines of Code)

### SIMRS Dummy Asli (Estimasi)

Dengan asumsi rata-rata **30 bytes per baris** untuk kode Java:

| Bahasa | Bytes | Estimasi LOC |
|---|---:|---:|
| Java | 116,835,304 | **~3,894,510 baris** |
| JavaScript | 20,250,587 | ~675,019 baris |
| PHP | 7,536,460 | ~251,215 baris |
| HTML | 4,579,259 | ~152,641 baris |
| CSS | 2,580,587 | ~86,019 baris |
| **TOTAL** | **153,419,432** | **~5,059,404 baris** |

> [!IMPORTANT]
> SIMRS Dummy adalah proyek yang telah dikembangkan selama **~10 tahun** oleh komunitas, dengan **800-1000 tabel database**, ratusan form Java Swing, ratusan laporan JasperReports, bridging BPJS, bridging SatuSehat, dan puluhan ribu fitur klinis/administratif.

### SIMRS-Web (Proyek Kita)

| Komponen | Baris Kode |
|---|---:|
| Backend `src/` (TypeScript) | **1,477 baris** |
| Frontend `src/` (TSX/CSS) | **1,646 baris** |
| Simulation Scripts (Python) | **1,469 baris** |
| Prisma Schema | **571 baris** |
| README + Config | **~150 baris** |
| **TOTAL** | **~5,313 baris** |

---

## 🔍 3. Perbandingan Head-to-Head

| Metrik | SIMRS Dummy (Asli) | SIMRS-Web (Kita) | Rasio |
|---|---|---|---|
| **Umur Proyek** | ~10 tahun | ~1 minggu | — |
| **Source Code Murni** | ~146.3 MB | ~1.3 MB | **1 : 112** |
| **Estimasi Total LOC** | ~5,059,404 baris | ~5,313 baris | **1 : 952** |
| **Bahasa Utama** | Java (76%) | TypeScript (58%) | — |
| **Bahasa Pendukung** | JS, PHP, HTML, CSS, Pascal | Python, CSS, SQL | — |
| **Tabel Database** | 800-1000+ tabel | 26 model (terdaftar) | **1 : ~38** |
| **Modul/Fitur** | 200+ modul | 8 modul | **1 : 25** |
| **Dependensi (Installed)** | JRE + .jar libraries | 988 MB (node_modules + venv) | — |

---

## 📈 4. Analisis Cakupan (Coverage Ratio)

Jika SIMRS Dummy = 100% fitur, berapa persen yang sudah kita cover?

| Kategori Fitur | SIMRS Dummy | SIMRS-Web | Status |
|---|---|---|---|
| **Pendaftaran Rawat Jalan** | ✅ | ✅ | Selesai |
| **Antrean Poliklinik** | ✅ | ✅ | Selesai |
| **Manajemen Bangsal** | ✅ | ✅ | Selesai |
| **Rekam Medis (CPPT/SOAP)** | ✅ | ✅ | Selesai |
| **Farmasi & E-Resep** | ✅ | ✅ | Selesai |
| **Kasir / Billing** | ✅ | ✅ | Selesai |
| **Double-Entry Accounting** | ✅ | ✅ | Selesai |
| **Autentikasi (Login)** | ✅ | ✅ | Selesai |
| Pendaftaran Rawat Inap | ✅ | ⏳ | Belum |
| Bridging BPJS (V-Claim/SEP) | ✅ | ⏳ | Fase 2 |
| INA-CBG / E-Klaim | ✅ | ❌ | Belum |
| SatuSehat (Kemenkes) | ✅ | ❌ | Belum |
| Laboratorium | ✅ | ❌ | Belum |
| Radiologi | ✅ | ❌ | Belum |
| Operasi / Kamar Bedah | ✅ | ❌ | Belum |
| IGD (Unit Gawat Darurat) | ✅ | ❌ | Belum |
| Gizi / Dapur | ✅ | ❌ | Belum |
| CSSD (Sterilisasi) | ✅ | ❌ | Belum |
| Inventory Non-Medis | ✅ | ❌ | Belum |
| HRD / Kepegawaian | ✅ | ❌ | Belum |
| Laporan Keuangan (RL 1-5) | ✅ | ❌ | Belum |
| JasperReports (Cetak Struk) | ✅ | ❌ | Belum |
| RBAC (Hak Akses per Modul) | ✅ | ⏳ | Fase 3 |
| Dan 180+ modul lainnya... | ✅ | ❌ | Belum |

### Estimasi Cakupan

| Metrik | Nilai |
|---|---|
| Modul yang tercakup | **8 dari ~200+** |
| Tabel yang di-mapping | **26 dari ~1000+** |
| **Persentase Coverage (Modul)** | **~4%** |
| **Persentase Coverage (Database)** | **~2.6%** |

---

## 💡 5. Kesimpulan Jujur

> [!CAUTION]
> **Fakta yang harus diakui:**
> Source code SIMRS-Web kita saat ini hanya **~0.1%** dari ukuran source code SIMRS Dummy asli. Ini bukan perbandingan yang setara — SIMRS Dummy telah dikembangkan selama satu dekade oleh komunitas RS seluruh Indonesia, sedangkan kita baru memulai fondasi dalam hitungan hari.

> [!TIP]
> **Kabar baiknya:**
> 8 modul inti yang telah kita bangun adalah **fondasi operasional terpenting** rumah sakit (pendaftaran → pemeriksaan → resep → kasir → akuntansi). Ini adalah tulang punggung (*backbone*) yang harus benar terlebih dahulu sebelum membangun 192 modul lainnya. Dan fondasi ini sudah **terbukti berjalan** (258/300 transaksi massal berhasil, 42 gagal karena ID collision — bukan bug logika).

### Prioritas Selanjutnya untuk Memperbesar Cakupan:
1. **Bridging BPJS** — karena ~70% RS Indonesia menggunakan BPJS
2. **Rawat Inap** — karena ini revenue utama RS
3. **Laboratorium & Radiologi** — karena ini penunjang medis wajib
4. **Laporan Keuangan (RL)** — karena ini persyaratan akreditasi RS

---

*Dokumen ini menjamin transparansi penuh terhadap posisi proyek kita relatif terhadap sistem yang ingin kita gantikan.*
