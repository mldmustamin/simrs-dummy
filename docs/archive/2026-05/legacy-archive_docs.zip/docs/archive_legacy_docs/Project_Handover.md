# 🚀 Dokumen Keberlanjutan Proyek (Project Handover)

Dokumen ini adalah **titik rekam jejak presisi (save state)** yang dirancang agar Anda dapat melanjutkan pengembangan proyek SIMRS ini kapan saja, meskipun sesi ini terputus atau kuota Anda habis. Cukup berikan dokumen ini kepada AI di sesi berikutnya, dan AI tersebut akan langsung memahami konteks penuh tanpa halusinasi.

---

## 📌 1. Prompt Wajib untuk Sesi Berikutnya

Jika Anda memulai sesi baru dengan AI, salin dan tempel **tepat** prompt di bawah ini pada pesan pertama Anda:

> **PROMPT UNTUK AI SESI BARU:**
> "Halo, kita sedang melanjutkan pengembangan sistem SIMRS (Sistem Informasi Manajemen Rumah Sakit) berbasis **SIMRS Dummy**. Backend menggunakan NestJS + Prisma ORM (Versi 5.11.0 wajib dipertahankan), database menggunakan MySQL (sik), dan testing menggunakan script Python.
> 
> Mohon **BACA, PAHAMI, DAN JANGAN ASUMSIKAN APAPUN** dari Artifact `Project_Handover.md`, `Migration_Strategy.md`, `System_Simplification_Audit.md`, `SOP_QnA.md`, dan `putangina.md` sebelum memulai. 
> 
> **Kondisi Terakhir (Save State):**
> 1. Fase 1 (Core Billing & Farmasi) sudah STABIL. 300 Dummy Data Test berhasil dijalankan dan semua transaksi seimbang (Balance).
> 2. Skema Prisma telah disesuaikan secara khusus untuk mengatasi benturan Enum MySQL `stts_bayar`, `pasien_jk`, dll (JANGAN me-regenerate schema dari awal tanpa introspeksi ketat).
> 3. Kita sedang bersiap memasuki **Fase 2 (Resolusi Legal & Rekam Medis BPJS)**.
> 
> **Tugas Pertamamu:** Baca semua artifact yang disebutkan, konfirmasi pemahamanmu terhadap Zero-Modification Policy database SIMRS Dummy, dan tanyakan padaku fitur Fase 2 mana yang ingin mulai dikerjakan."

---

## 🏗️ 2. Status Proyek Saat Ini (Precision State)

### ✅ Yang Telah Diselesaikan (Fase 1: Stabil)
- **Backend Infrastructure:** NestJS telah dikonfigurasi, PrismaClient versi 5.11.0 distabilkan (versi 7.x terbukti crash karena bug engine Enum).
- **Modul Kasir (Tagihan & Pembayaran):** Berhasil menarik `reg_periksa`, menjumlahkan tarif dari `rawat_jl_dr`, `resep_obat`, dll.
- **Modul Farmasi (Inventori):** Logic integrasi pengeluaran barang (`detail_pemberian_obat`) sudah diselaraskan.
- **Double-Entry Accounting:** Saat pembayaran berhasil, sistem otomatis menyeimbangkan jurnal (`nota_jalan`, `jurnal`, `detailjurnal`) di database asil SIMRS Dummy (Double-entry balance check: **LULUS**).
- **Load / Logic Test:** Skrip `generate_sql.py` telah memasukkan 300 pasien dummy beserta 1-3 tindakan dan obat bervariasi. Skrip `verify_300.py` telah memvalidasi seluruh 300 tagihan secara massal tanpa error.
- **Penyederhanaan & Hutang Teknis:** Dicatat jujur di `System_Simplification_Audit.md` dan `putangina.md`.

### ⏳ Yang Menunggu Dikerjakan (Fase 2 & Fase 3)
1. **Fase 2 (BPJS & E-Rekam Medis):**
   - Integrasi V-Claim / SEP BPJS.
   - Modul CPPT (Catatan Perkembangan Pasien Terintegrasi) dan mapping ICD-10.
2. **Fase 3 (Arsitektur & Keamanan):**
   - Implementasi RBAC (Role-Based Access Control) dengan JWT.
   - Server-Side Pagination untuk mengatasi load ribuan data master.

---

## ⚙️ 3. Pedoman Teknis & Pantangan (Golden Rules)

Agar AI berikutnya tidak merusak proyek ini, Anda (atau AI) harus mematuhi aturan berikut:

1. **Strict Zero-Modification Policy (DDL):**
   DILARANG KERAS mengubah struktur tabel, menambah kolom, atau menghapus tabel asli bawaan SIMRS Dummy. Jika butuh kolom baru, gunakan tabel ekstensi (contoh: `ext_pasien_simrs`).
2. **Prisma Version Lock:**
   JANGAN perbarui Prisma ke versi terbaru (7.x+). Versi yang kompatibel dan stabil dengan kompleksitas Enum SIMRS Dummy di MySQL adalah **5.11.0**. Perintah regenerasi yang aman: `npx prisma generate` (setelah mengubah manual schema.prisma).
3. **Penanganan Enum Database vs Prisma:**
   SIMRS Dummy menggunakan banyak `enum` di MySQL. Prisma seringkali gagal memetakan nilai Enum (seperti `Belum_Bayar` vs `Belum Bayar`). Jika terjadi *PrismaClientKnownRequestError*, penyelesaiannya adalah menyesuaikan tipe data Enum secara manual di file `schema.prisma`. Jangan mencoba mengubah nilai di dalam Database!

---

## 📂 4. Lokasi File Penting (Direktori Kerja)

Jika AI butuh mencari sesuatu, berikut adalah petanya:
- **Root Backend:** `/home/gudang-data-kantor/simrs-web/simrs-backend`
- **Root Script Pengujian:** `/home/gudang-data-kantor/simrs-web/simulation`
- **File Skema Database (Wajib Rujukan):** `/home/gudang-data-kantor/simrs-web/simrs-backend/prisma/schema.prisma`
- **Logic Kasir Utama:** `/home/gudang-data-kantor/simrs-web/simrs-backend/src/kasir/kasir.service.ts`
- **Script Generator 300 Dummy:** `/home/gudang-data-kantor/simrs-web/simulation/generate_sql.py`
- **Script Validasi 300 Dummy:** `/home/gudang-data-kantor/simrs-web/simulation/verify_300.py`

---

## 🎯 5. Cara Memulai Ulang Server

Jika server mati atau mesin di-restart, gunakan perintah berikut di terminal:
```bash
# 1. Masuk ke direktori backend
cd /home/gudang-data-kantor/simrs-web/simrs-backend

# 2. Pastikan port 4000 kosong
kill -9 $(lsof -t -i:4000)

# 3. Jalankan server (gunakan tmux/pm2 jika ingin berjalan di latar belakang)
PORT=4000 node dist/src/main.js
```

---
*Dokumen ini menjamin 100% presisi peralihan tugas antar AI. Simpan dengan baik!*
