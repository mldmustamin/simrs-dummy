# SIMRS-Web: Panduan Standarisasi Format & Kompatibilitas Data

Dokumen ini adalah **Buku Aturan Baku (Rulebook)** untuk format tipe data, struktur *identifier*, dan konsistensi antar-modul di SIMRS-Web. Kesalahan format antar modul (misal: format tanggal pendaftaran berbeda dengan format tanggal rekam medis) akan menyebabkan *Foreign Key Constraint* patah atau data tidak terbaca oleh aplikasi Java Desktop asli.

Seluruh *developer* (baik Frontend, Backend, maupun Sistem Pihak Ketiga) **WAJIB** mematuhi format SIMRS Dummy-Native di bawah ini.

---

## 1. Standarisasi Nomor Unik (Identifiers)

Nomor-nomor unik ini bertindak sebagai *Primary Key* atau pengikat *Foreign Key* lintas modul. Dilarang keras men- *generate* UUID atau *Auto Increment* untuk entitas utama.

### A. Nomor Rawat / Pendaftaran (`no_rawat`)
*   **Modul Pemilik:** Front Office / Pendaftaran (Tabel `reg_periksa`)
*   **Format Wajib:** `YYYY/MM/DD/xxxxxx` (Tahun 4 digit / Bulan 2 digit / Tanggal 2 digit / Nomor urut 6 digit)
*   **Contoh:** `2026/02/23/000001`
*   **Validasi Panjang:** Maksimal 17 karakter.
*   **Pengguna (Hilir):** Wajib dikirim utuh tanpa modifikasi ke modul CPPT, Ranap, Farmasi, Laboratorium, dan Kasir.

### B. Nomor Rekam Medis (`no_rkm_medis`)
*   **Modul Pemilik:** Pasien Baru
*   **Format Wajib:** `xxxxxx` (Urutan angka numerik, diawali nol di depan)
*   **Contoh:** `000001`
*   **Validasi Panjang:** 6 hingga 15 karakter (tergantung konfigurasi SIMRS Dummy RS).

### C. Nomor Resep (`no_resep`)
*   **Modul Pemilik:** Farmasi / Poli (Tabel `resep_obat`)
*   **Format Wajib:** `YYYYMMDDxxxx` (Tanpa garis miring. Tahun 4 digit, Bulan 2 digit, Tanggal 2 digit, Nomor urut 4 digit)
*   **Contoh:** `202603040001`
*   **Validasi Panjang:** 12 - 14 karakter.

---

## 2. Standarisasi Waktu (Temporal Data)

Karena SIMRS Dummy sering memisahkan Tanggal dan Waktu ke dalam dua kolom yang berbeda (tidak digabung menjadi `DATETIME` atau `TIMESTAMP`), backend NestJS wajib melakukan pemisahan (*splitting*) sebelum melakukan *INSERT*.

### A. Tanggal (`tgl_registrasi`, `tgl_perawatan`, `tgl_peresepan`)
*   **Tipe Database:** `DATE`
*   **Format Wajib (Backend ke DB):** `YYYY-MM-DD` (Standar ISO 8601).
*   **Contoh:** `2026-02-25`
*   **Di Frontend:** Boleh dirender menggunakan `DD/MM/YYYY` atau *Locale Date* untuk keperluan UI, namun **payload API harus selalu** `YYYY-MM-DD`.

### B. Jam / Waktu (`jam_reg`, `jam_rawat`, `jam_peresepan`)
*   **Tipe Database:** `TIME`
*   **Format Wajib (Backend ke DB):** `HH:MM:SS` (24-Jam Format).
*   **Contoh:** `08:07:56`, `22:21:22`

> [!WARNING]
> Jangan pernah mengirim objek utuh `Date` Javascript (e.g. `2026-05-26T08:00:00.000Z`) langsung ke kueri SQL mentah untuk kolom berjenis `TIME` atau `DATE` di SIMRS Dummy. Gunakan *formatter* (seperti `moment.js` atau fungsi bawaan Prisma) untuk memecahnya menjadi format `YYYY-MM-DD` dan `HH:MM:SS`.

---

## 3. Standarisasi Tipe Data Spesifik Medis & Keuangan

### A. Tipe Desimal (Kalkulasi Stok & Harga)
*   **Kolom Terkait:** `jml` (Jumlah Obat), `p1`, `p2` (Komposisi Racikan), Tarif/Harga (`ralan`, `ranap`).
*   **Tipe Database:** `DOUBLE` atau `DECIMAL`
*   **Format di Frontend/JSON Payload:** Harus berupa *Number* / *Float* murni (`1.5`, bukan `"1,5"` atau `"1.5"` dalam bentuk String).
*   **Keuangan:** Tidak ada tipe khusus *Money* di SIMRS Dummy MySQL, semuanya menggunakan `DOUBLE`. Pembulatan rupiah hanya terjadi di level antarmuka Frontend.

### B. Standarisasi Enumerasi Status (Status Data)
SIMRS Dummy banyak memanfaatkan tipe `ENUM` dan `VARCHAR(1)` hingga `VARCHAR(50)` untuk *state management*. Jangan pernah mengirim nilai di luar kesepakatan bawaan berikut:
*   **Status Kunjungan (`stts` di `reg_periksa`):** `'Belum'`, `'Sudah'`, `'Batal'`, `'Dirawat'`, `'Dirujuk'`
*   **Status Rawat (`status_lanjut`):** `'Ralan'`, `'Ranap'`
*   **Status Kamar (`statusdata` di `kamar`):** `'KOSONG'`, `'ISI'`, `'DIBERSIHKAN'`
*   **Status Obat (`status` di `databarang`):** `'1'` (Aktif), `'0'` (Tidak Aktif)

---

## 4. API Payload & Inter-Module Communication

Untuk menjamin modul seperti CPPT, Farmasi, dan Kasir tidak "berbicara bahasa yang berbeda", Payload standar antar-modul harus mengikuti:

### Standard Response Wrapper (NestJS)
```json
{
  "statusCode": 200,
  "message": "Operasi Berhasil",
  "data": { ... }
}
```

### Dependency Chain (Rantai Wajib)
*   **Modul Kasir/Billing** TIDAK BOLEH memproses data jika Modul Farmasi (Penyerahan) belum melengkapi kolom `tgl_penyerahan` yang valid (selain `0000-00-00`).
*   **Modul Ranap** TIDAK BOLEH memutasi pasien tanpa `no_rawat` dari Modul Pendaftaran.
*   **Modul RME/CPPT** wajib melempar parameter `no_rawat` dan `kd_dokter` ke dalam URL State atau Global State (Zustand) agar saat dokter berpindah ke tab Farmasi (E-Resep), `no_rawat` sudah terisi otomatis tanpa perlu mengetik ulang.

> [!IMPORTANT]
> **Zero-Modification Policy (Aturan Harga Mati):**
> Jika Frontend atau modul baru membutuhkan struktur data yang bentuknya berbeda dari SIMRS Dummy, lakukan transformasi (*mapping*) di lapisan layanan Backend (NestJS). **DILARANG MERUBAH TIPE DATA, PANJANG KARAKTER (VARCHAR), ATAU MENAMBAHKAN AUTO-INCREMENT PADA STRUKTUR TABEL MySQL `sik` ASLI.**
