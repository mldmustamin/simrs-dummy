# Goal Description

Melunasi 15 Hutang Teknis (*Technical Debt*) yang tercatat di `putangina.md` secara tuntas dan jujur. Tujuan utama dari fase ini adalah mengubah aplikasi dari sekadar "Minimum Viable Product" (MVP) yang rentan, menjadi sistem berkelas *Enterprise-Ready* yang tingkat akurasi data finansial, inventori, dan legalitas BPJS-nya setara (bahkan mengungguli) aplikasi Java desktop SIMRS Dummy asli.

## User Review Required

> [!WARNING]
> **PERINGATAN RISIKO REFAKTORISASI BESAR**
> Pelunasan hutang ini mengharuskan kita membedah ulang (`refactor`) struktur Modul Kasir, Modul Farmasi, dan Modul Pendaftaran. Selama proses ini, beberapa fitur mungkin tidak dapat diakses sementara waktu hingga seluruh kabel logika (seperti Jurnal Akuntansi dan Mutasi Stok) tersambung dengan benar. Apakah Anda setuju dengan pendekatan bedah total ini?

## Open Questions

> [!IMPORTANT]
> **PERTANYAAN STRATEGIS UNTUK SYSTEM ANALYST:**
> 1. **Fase Prioritas:** Menyelasaikan 15 hutang sekaligus dalam satu waktu berisiko merusak sistem (*System Break*). Bolehkah saya membaginya menjadi 3 Fase Eksekusi (Fase 1: Finansial & Inventori, Fase 2: BPJS & Rekam Medis, Fase 3: UI & RBAC) dan kita kerjakan satu per satu?
> 2. **BPJS Bridging:** Untuk implementasi SEP BPJS, apakah RS Anda memiliki *Cons ID* dan *Secret Key* V-Claim aktif untuk testing, atau haruskah saya membuatkan *Mock API* (API Tiruan) yang mensimulasikan respon BPJS agar aplikasi tetap bisa berjalan tanpa koneksi BPJS asli?

## Proposed Changes

Karena cakupannya sangat masif, perombakan akan dipecah berdasarkan Komponen Inti.

---

### Phase 1: Resolusi Finansial & Inventori (Tingkat Kritis)

Fokus utama adalah menyelamatkan Laporan Keuangan dan Stok Gudang.

#### [MODIFY] `simrs-backend/prisma/schema.prisma`
- Menambahkan model `jurnal`, `detailjurnal`, dan `rekening` untuk sistem akuntansi.
- Menambahkan model `riwayat_barang_medis` untuk pelacakan fisik FIFO/LIFO.
- Menambahkan model `set_embalase` untuk menarik standar biaya kemasan dan tuslah.

#### [MODIFY] `simrs-backend/src/kasir/kasir.service.ts`
- **Sistem Akuntansi (Double-Entry Bookkeeping):** Mengubah fungsi `bayar()` agar setiap kali nota tercetak, sistem otomatis melakukan `INSERT` ke tabel `jurnal` dan `detailjurnal`. Pendapatan akan dipecah secara otomatis ke Kode Rekening (Debit Kas, Kredit Pendapatan Obat, Kredit Jasa Medis).

#### [MODIFY] `simrs-backend/src/farmasi/farmasi.service.ts`
- **Mutasi Stok Asli:** Mengubah validasi resep agar melakukan pemotongan stok berdasar FIFO ke tabel `gudangbarang`.
- **Riwayat Medis:** Mencatat pergerakan barang (Status: 'Pemberian Obat') ke `riwayat_barang_medis` beserta *No Batch* dan *No Faktur*.
- **Tuslah & Embalase:** Memasukkan biaya kemasan dan jasa layanan apoteker secara dinamis ke dalam perhitungan tagihan obat.

---

### Phase 2: Resolusi Legal & Rekam Medis BPJS (Tingkat Krusial)

#### [MODIFY] `simrs-backend/prisma/schema.prisma`
- Menambahkan `bridging_sep`, `diagnosa_pasien`, `penyakit` (ICD-10).

#### [MODIFY] `simrs-backend/src/pendaftaran/pendaftaran.service.ts`
- Memicu *Mock API* atau *Real API* V-Claim BPJS saat pasien terdaftar menggunakan penjamin BPJS.
- Menerbitkan `no_sep` dan menyimpannya di tabel `bridging_sep`.

#### [MODIFY] `simrs-backend/src/cppt/cppt.service.ts`
- Memaksa pengisian kode ICD-10 (Tabel `penyakit`) saat dokter menyimpan CPPT, dan menyimpannya di `diagnosa_pasien`.

#### [MODIFY] `simrs-frontend/src/pages/MedicalRecord.tsx`
- Menambahkan komponen *AutoComplete Search* untuk mencari kode ICD-10 secara cepat bagi dokter.

---

### Phase 3: Resolusi Arsitektur (RBAC) & Kosmetik (Tingkat Menengah & Ringan)

#### [MODIFY] `simrs-backend/src/auth/auth.service.ts`
- Mengubah alur autentikasi JWT agar membaca puluhan kolom boolean (seperti `penyakit`, `kasir_ralan`, `obat`) dari tabel `user`. Token JWT akan menyimpan *payload* RBAC ini.

#### [MODIFY] `simrs-frontend/src/App.tsx`
- Membuat komponen `<ProtectedRoute requiredRole="kasir_ralan">` yang akan memblokir Apoteker dari membuka halaman Kasir, dan memblokir Kasir dari meracik resep.

#### [MODIFY] Semua Komponen Frontend (Farmasi, Kasir, RM)
- Mengimplementasikan `Server-Side Pagination` untuk menangani jutaan baris data pasien tanpa membuat browser kehabisan memori.

---

## Verification Plan

### Automated Tests
- Menjalankan kembali skrip `generate_300_patients.py` setelah seluruh fase selesai.
- Memverifikasi apakah total saldo di tabel `detailjurnal` seimbang (*Balance* antara Total Debit dan Kredit).

### Manual Verification
- Melakukan verifikasi silang: Membuka SIMRS-Web dan Aplikasi Java SIMRS Dummy Desktop secara bersamaan, melakukan pendaftaran dan pembayaran di Web, lalu mencetak Laporan Keuangan Harian di Aplikasi Desktop untuk melihat apakah transaksi dari Web masuk dengan angka HPP dan Laba yang identik.
