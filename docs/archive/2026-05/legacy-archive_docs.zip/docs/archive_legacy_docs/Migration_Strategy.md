# Dokumen Teknis: Strategi & Pendekatan Migrasi SIMRS

Migrasi sistem rumah sakit adalah operasi paling berisiko tinggi (*High-Risk Operation*) dalam siklus IT medis. Kehilangan data rekam medis atau tagihan pasien bisa berujung pada sengketa hukum atau kegagalan operasional. 

Dokumen ini adalah cetak biru (*Blueprint*) standar yang harus diterapkan saat memindahkan data dari SIMRS Lama milik Rumah Sakit menuju ekosistem SIMRS-Web kita.

---

## Skenario Migrasi

Pendekatan teknis akan dibagi menjadi dua berdasarkan kondisi rumah sakit target:

### Skenario A: Migrasi dari SIMRS Dummy (Desktop Java) ke SIMRS-Web
Jika rumah sakit saat ini sudah memakai SIMRS Dummy versi Java Desktop dan ingin beralih ke versi Web kita.
- **Pendekatan:** *Zero-Data Migration* (Plug and Play).
- **Strategi:** Kita TIDAK melakukan pemindahan atau modifikasi data sama sekali. Kita hanya perlu mengarahkan koneksi `.env` Backend NestJS kita (`DATABASE_URL="mysql://user:pass@ip_server_rs:3306/sik"`) ke server database MariaDB mereka yang sudah berjalan.
- **Fase Transisi:** *Parallel Run* (Berjalan Paralel). Beberapa loket kasir memakai versi Web, sementara poli lain masih memakai Java. Karena arsitektur (Prisma Schema) kita sangat *native* terhadap SIMRS Dummy, tidak akan ada tabrakan (*collision*) data.

### Skenario B: Migrasi dari SIMRS Vendor Lain (Non-SIMRS Dummy) ke SIMRS-Web
Jika rumah sakit memakai SIMRS vendor lain (SQL Server, PostgreSQL, atau MySQL custom). Ini membutuhkan proses **ETL (Extract, Transform, Load)** yang sangat disiplin.

---

## SOP Pipeline ETL (Khusus Skenario B)

Proses migrasi HARUS dilakukan secara berurutan (*Sequential*) karena adanya *Foreign Key Constraint*. Jangan pernah melakukan pemindahan tabel Transaksi jika tabel Master belum selesai dipindahkan.

### Tahap 1: Ekstraksi (Pembersihan Data Lama)
Sistem lama sering kali kotor (misalnya: data pasien ganda, tanggal lahir "0000-00-00", NIK KTP kosong).
- Lakukan pembersihan manual (Data Cleansing) via Excel/CSV sebelum disentuh oleh sistem baru.
- Buang data kunjungan/registrasi uji coba (*dummy*) dari vendor lama.

### Tahap 2: Transformasi (Penyesuaian Standarisasi)
Data lama harus dikonversi menyesuaikan **[Data_Standardization_Rules.md](Data_Standardization_Rules.md)** kita:
1.  **Konversi `no_rkm_medis` (RM Pasien):** Jika RM lama adalah `1234`, transformasikan menjadi `001234` (Padded 6 digit) sesuai format pasien SIMRS Dummy.
2.  **Konversi `no_rawat`:** Sistem lama mungkin memiliki ID Transaksi bebas (misal: `TRX-99812`). Ini WAJIB diubah menggunakan algoritma konversi menjadi `YYYY/MM/DD/NoUrut` sesuai tanggal pendaftaran pasien lama tersebut.
3.  **Pemisahan Tanggal & Waktu:** Jika sistem lama menggunakan tipe `DATETIME`, skrip migrasi harus memecahnya menjadi kolom `DATE` dan `TIME`.

### Tahap 3: Loading (Fase Injeksi Berurutan)
Pemindahan (INSERT) data wajib menaati hierarki *Dependency* berikut. Kegagalan mematuhi urutan ini akan berujung pada error *Cannot add or update a child row*.

**Urutan 1: Master Data Utama (Prioritas Tertinggi)**
- `pegawai` & `dokter`
- `poliklinik`
- `penjab` (Penjamin / Asuransi / BPJS)
- `databarang` (Master Obat) & `gudangbarang`

**Urutan 2: Master Data Pasien**
- `pasien` (Wajib terikat dengan `kd_pj` / Penjamin yang sudah di-insert pada Urutan 1).

**Urutan 3: Data Historis Klinis (Transaksi)**
- `reg_periksa` (Pendaftaran/Registrasi). Di-generate ulang *no_rawat*-nya.
- `pemeriksaan_ralan` & `pemeriksaan_ranap` (CPPT/SOAP Dokter).
- `diagnosa_pasien` (ICD-10 BPJS).

**Urutan 4: Data Keuangan & Tagihan (History)**
- Jika terlalu rumit, rumah sakit biasanya **TIDAK** memigrasikan tabel kasir (`billing`) dari sistem lama secara rinci. Cukup migrasikan *Piutang Pasien* (Total sisa tagihan) sebagai saldo awal.

---

## Mitigasi & Rollback Plan

1.  **Fase Staging (Sandbox):** Jangan pernah melakukan migrasi langsung ke server produksi. Kloning (*dump*) database sistem lama ke server *Staging*, lalu jalankan skrip konversi Python (mirip *Dry-Run* SOP kita).
2.  **Cut-Off Time:** Tentukan waktu transisi absolut (misalnya: Hari Sabtu jam 23:59). Mulai hari Minggu pukul 00:00, pendaftaran pasien sudah wajib memakai SIMRS-Web. Pendaftaran lama yang belum ditagih di kasir harus diselesaikan di sistem lama (tidak dimigrasi tagihannya).
6.  **Tabel Relasi Bayangan (Shadow Table):** Buat tabel `migrasi_log` di MariaDB yang memetakan `id_lama` ke `id_baru_simrs_dummy`. Jika suatu hari ada auditor menanyakan rekam medis lama pasien, kita bisa melacaknya dari tabel bayangan ini.

---

## 🔐 Manajemen Risiko Keamanan Data (IDOR & Obfuscation)

Terkait dengan pengamanan ID Rekam Medis (`no_rkm_medis`) dan ID Transaksi (`no_rawat`), implementasi *Obfuscation* (Penyamaran Data) pada Layer API akan memunculkan "Dampak 2 Sisi". Satu sisi aman dari peretas (Hacker), di sisi lain membingungkan administrator atau *engineer* saat melakukan *cross-check* manual dan migrasi.

Berikut adalah **Metodologi Teknis Presisi** untuk mengatasi benturan tersebut:

### 1. Metodologi Obfuscation (Layer API Backend)
Kita menggunakan pustaka kriptografi **Hashids** (atau AES-256-GCM) dengan *Salt* rahasia yang disimpan secara lokal di mesin server (file `.env`), bukan di database.
- **Skema Encoding (API Response):** Ketika Backend mengambil profil pasien `000001` dari MySQL, *Middleware Interceptor* NestJS langsung menyandikan `000001` ➔ `X7f9K2mPq`. Frontend/Mobile App HANYA menerima dan menyimpan `X7f9K2mPq`.
- **Skema Decoding (API Request):** Ketika Frontend mengirim Payload `{ "pasien_id": "X7f9K2mPq" }`, *Middleware Pipe* NestJS akan membedahnya kembali menjadi `000001` *sebelum* diteruskan ke dalam blok logika bisnis (Service).

### 2. Pengecualian pada Pipeline Migrasi (ETL)
**Proses Migrasi tidak boleh menggunakan Layer API Backend (Tanpa Obfuscation).**
- Semua perpindahan data (Ekstraksi, Transformasi, dan Loading/Injeksi) **WAJIB** dilakukan langsung di tingkat *Database Management System* (via Script Python murni atau SQL Dump).
- Jika *engineer* menggunakan Script Migrasi Python, koneksi dilakukan langsung melalui library `mysql-connector` murni ke port 3306 (Database).
- Hal ini menjamin bahwa seluruh ID di-injeksi dengan format *Sequential* (angka berurutan asli SIMRS Dummy) secara mentah tanpa mengalami kerusakan pengacakan (Enkripsi).

### 3. Metodologi Pemeriksaan Manual (Manual Audit)
Jika seorang Perawat melapor ke tim IT: *"Sistem mencatat transaksi gagal untuk Pasien X7f9K2mPq!"*, seorang Database Admin (DBA) yang membuka MySQL mentah **tidak akan pernah menemukan** ID `X7f9K2mPq` di dalam tabel mana pun.
Ini adalah kerentanan operasional. Cara mengatasinya:
- **Admin Utility API (The Decoder Ring):** Kita akan membangun satu *endpoint* tersembunyi (misal: `GET /admin/security/decode/:hash`) di backend.
- Endpoint ini **mewajibkan** akses dengan Token JWT ber-role **"SuperAdmin"** (Role-Based Access Control ketat).
- Tim IT dapat memasukkan kode acak `X7f9K2mPq` ke dalam Utility ini untuk mendapatkan terjemahan mentahnya: `000001`.
- Setelah mendapatkan ID Mentah, DBA dapat melakukan *query* ke MySQL secara manual (`SELECT * FROM pasien WHERE no_rkm_medis = '000001'`) untuk proses *troubleshooting* atau audit data.

Metode di atas menjamin pemisahan mutlak (*Absolute Decoupling*) antara **Keamanan Eksposur API** dan **Integritas Operasional Database Latar Belakang**.
