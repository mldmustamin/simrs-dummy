# 📂 Dokumentasi Lengkap Seluruh File & Folder Proyek SIMRS-Web

> Dokumen ini mencatat **setiap file dan folder** yang relevan dengan proyek ini, termasuk source code, konfigurasi, script pengujian, skema database, dan dokumen proyek (artifact). Tidak ada yang terlewat.

---

## 🏠 Root Proyek

```
/home/gudang-data-kantor/simrs-web/
```

| File/Folder | Tipe | Ukuran | Fungsi |
|---|---|---|---|
| [README.md](file:///home/gudang-data-kantor/simrs-web/README.md) | File | 3.8 KB | **Kompas utama proyek.** Berisi filosofi, aturan emas (Zero-Modification DB SIMRS Dummy), tech stack, kredensial database, status eksekusi modul, dan pesan untuk AI agar melanjutkan dengan benar. |
| `simrs-backend/` | Folder | — | Backend API (NestJS + Prisma ORM) |
| `simrs-frontend/` | Folder | — | Frontend UI (Vite + React + TailwindCSS) |
| `simulation/` | Folder | — | Script Python untuk pengujian & validasi |

---

## ⚙️ Backend: `simrs-backend/`

### Konfigurasi & Root Files

| File | Ukuran | Fungsi |
|---|---|---|
| `.env` | Lokal | **Kredensial database dan secret runtime.** Tidak boleh masuk repository; gunakan `.env.example` sebagai template tanpa nilai rahasia. |
| [package.json](file:///home/gudang-data-kantor/simrs-web/simrs-backend/package.json) | 2.1 KB | Dependensi utama: `@nestjs/common@^11.0.1`, `@nestjs/jwt@^11.0.2`, `@prisma/client@^5.11.0`, `mysql2@^3.22.3`. Script: `build`, `start:dev`, `test`, `test:e2e`. |
| [tsconfig.json](file:///home/gudang-data-kantor/simrs-web/simrs-backend/tsconfig.json) | 674 B | TypeScript config: target `ES2023`, module `nodenext`, `strictNullChecks: true`, `emitDecoratorMetadata: true` (wajib untuk NestJS decorator). Output: `./dist`. |
| [tsconfig.build.json](file:///home/gudang-data-kantor/simrs-web/simrs-backend/tsconfig.build.json) | 97 B | Extends tsconfig.json, exclude `node_modules`, `test`, `dist`. |
| [nest-cli.json](file:///home/gudang-data-kantor/simrs-web/simrs-backend/nest-cli.json) | 171 B | NestJS CLI config: `sourceRoot: "src"`, `deleteOutDir: true` saat build. |
| [eslint.config.mjs](file:///home/gudang-data-kantor/simrs-web/simrs-backend/eslint.config.mjs) | 899 B | ESLint konfigurasi untuk TypeScript linting. |
| [.prettierrc](file:///home/gudang-data-kantor/simrs-web/simrs-backend/.prettierrc) | 52 B | Prettier formatter: `singleQuote: true`, `trailingComma: all`. |
| [.gitignore](file:///home/gudang-data-kantor/simrs-web/simrs-backend/.gitignore) | 705 B | Ignore: `node_modules/`, `dist/`, `.env`, `*.log`. |
| [README.md](file:///home/gudang-data-kantor/simrs-web/simrs-backend/README.md) | 5 KB | Dokumentasi NestJS boilerplate. |
| [nestjs.log](file:///home/gudang-data-kantor/simrs-web/simrs-backend/nestjs.log) | 43 B | File log output NestJS (runtime). |
| [dummy_generator.js](file:///home/gudang-data-kantor/simrs-web/simrs-backend/dummy_generator.js) | 3.6 KB | Script Node.js untuk generate dummy SQL (versi legacy, digantikan oleh `simulation/generate_sql.py`). |
| [test_prisma.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/test_prisma.ts) | 460 B | Script TypeScript untuk menguji koneksi PrismaClient ke database. |
| `node_modules/` | Folder | — | Dependensi npm terinstal (727 packages). **Jangan disentuh.** |
| `dist/` | Folder | — | Output build (`nest build`). Mirror dari `src/` dalam JavaScript. **Ini yang dijalankan oleh `node dist/src/main.js`.** |

---

### Skema Database: `simrs-backend/prisma/`

| File | Ukuran | Fungsi |
|---|---|---|
| [schema.prisma](file:///home/gudang-data-kantor/simrs-web/simrs-backend/prisma/schema.prisma) | 17 KB (571 baris) | ⭐ **SUMBER KEBENARAN SKEMA DATABASE.** Mendefinisikan 26 model (tabel) yang digunakan SIMRS-Web. Berisi relasi antar tabel, tipe data, dan enum kustom (`pasien_jk`, `rawat_jl_dr_stts_bayar`). **Perubahan di sini harus diikuti `npx prisma generate` + `npm run build`.** |
| [schema-introspect.prisma](file:///home/gudang-data-kantor/simrs-web/simrs-backend/prisma/schema-introspect.prisma) | 2.3 MB | Hasil introspeksi penuh (`npx prisma db pull`) dari SELURUH 1000+ tabel database SIMRS Dummy. Digunakan sebagai **referensi** untuk melihat struktur tabel asli. **Jangan dipakai langsung untuk generate.** |

---

### Source Code: `simrs-backend/src/`

#### Entry Point & Root Module

| File | Baris | Fungsi |
|---|---|---|
| [main.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/main.ts) | ~10 | Entry point. Membuat NestJS app, listen di port dari `process.env.PORT` (default 3000, kita pakai 4000). |
| [app.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/app.module.ts) | ~25 | **Root Module.** Import semua modul: `PrismaModule`, `AuthModule`, `PatientModule`, `RegistrationModule`, `QueueModule`, `BedModule`, `RmeModule`, `FarmasiModule`, `KasirModule`. |
| [app.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/app.controller.ts) | ~10 | Root controller. `GET /` → health check. |
| [app.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/app.service.ts) | ~5 | Root service. Returns "Hello World!". |
| [app.controller.spec.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/app.controller.spec.ts) | ~15 | Unit test untuk root controller. |

---

#### Modul `prisma/` — Koneksi Database

| File | Baris | Fungsi |
|---|---|---|
| [prisma.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/prisma/prisma.service.ts) | 14 | **PrismaClient singleton.** Extends `PrismaClient`, implements `OnModuleInit`. Memanggil `$connect()` saat modul dimulai. Semua service lain meng-inject service ini untuk akses database. |
| [prisma.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/prisma/prisma.module.ts) | ~8 | Module wrapper. `@Global()` agar PrismaService tersedia di seluruh aplikasi tanpa import ulang. |
| [prisma.service.spec.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/prisma/prisma.service.spec.ts) | ~10 | Unit test PrismaService. |

---

#### Modul `auth/` — Autentikasi & JWT

| File | Baris | Fungsi |
|---|---|---|
| [auth.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/auth/auth.service.ts) | 45 | Login logic. Query tabel `admin` SIMRS Dummy menggunakan `AES_DECRYPT` dengan key dari environment variable. Jika valid, generate JWT token. |
| [auth.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/auth/auth.controller.ts) | ~15 | `POST /auth/login` — menerima `{username, password}`, return JWT. |
| [auth.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/auth/auth.module.ts) | ~15 | Module definition. Import `JwtModule` dengan secret key dan `signOptions: { expiresIn: '8h' }`. |
| [auth.controller.spec.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/auth/auth.controller.spec.ts) | ~12 | Unit test. |
| [auth.service.spec.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/auth/auth.service.spec.ts) | ~12 | Unit test. |

---

#### Modul `patient/` — Master Data Pasien

| File | Baris | Fungsi |
|---|---|---|
| [patient.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/patient/patient.service.ts) | 31 | `findAll()`: list pasien. `findByRM(rm)`: cari pasien berdasarkan `no_rkm_medis`. Query ke tabel `pasien`. |
| [patient.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/patient/patient.controller.ts) | ~18 | `GET /patient` — list. `GET /patient/:rm` — detail. |
| [patient.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/patient/patient.module.ts) | ~8 | Module definition. |

---

#### Modul `registration/` — Pendaftaran Rawat Jalan

| File | Baris | Fungsi |
|---|---|---|
| [registration.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/registration/registration.service.ts) | 73 | `daftar()`: Membuat record baru di `reg_periksa`. Generate `no_rawat` format `YYYY/MM/DD/NNNNNN` (auto-increment urut per hari). Generate `no_reg` urut per poli per hari. |
| [registration.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/registration/registration.controller.ts) | ~15 | `POST /registration` — terima `{no_rkm_medis, kd_dokter, kd_poli, kd_pj}`. |
| [registration.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/registration/registration.module.ts) | ~8 | Module definition. |

---

#### Modul `queue/` — Antrean Poliklinik

| File | Baris | Fungsi |
|---|---|---|
| [queue.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/queue/queue.service.ts) | 34 | `getAntrian(kd_poli)`: Ambil daftar pasien yang terdaftar hari ini di poliklinik tertentu. Order by `no_reg`. |
| [queue.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/queue/queue.controller.ts) | ~10 | `GET /queue/:poli` |
| [queue.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/queue/queue.module.ts) | ~8 | Module definition. |

---

#### Modul `bed/` — Manajemen Bangsal / Tempat Tidur

| File | Baris | Fungsi |
|---|---|---|
| [bed.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/bed/bed.service.ts) | 53 | `getKetersediaan()`: Query tabel `kamar` + `bangsal` + `kamar_inap`. Hitung kapasitas vs terisi. Return ketersediaan per bangsal. |
| [bed.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/bed/bed.controller.ts) | ~12 | `GET /bed/availability` |
| [bed.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/bed/bed.module.ts) | ~8 | Module definition. |

---

#### Modul `rme/` — Rekam Medis Elektronik (CPPT/SOAP)

| File | Baris | Fungsi |
|---|---|---|
| [rme.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/rme/rme.service.ts) | 148 | `getCPPT(no_rawat)`: Ambil catatan SOAP dari `pemeriksaan_ralan`. `addCPPT()`: Tulis SOAP baru (Subjective, Objective, Assessment, Plan). `addDiagnosa()`: Insert ICD-10 ke `diagnosa_pasien`. |
| [rme.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/rme/rme.controller.ts) | ~35 | `GET /rme/:no_rawat` — baca CPPT. `POST /rme/:no_rawat` — tulis SOAP. `POST /rme/:no_rawat/diagnosa` — tambah ICD-10. |
| [rme.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/rme/rme.module.ts) | ~8 | Module definition. |

---

#### Modul `farmasi/` — Obat, Resep & Inventori

| File | Baris | Fungsi |
|---|---|---|
| [farmasi.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/farmasi/farmasi.service.ts) | 130 | `getStok()`: Query `databarang` + `gudangbarang` untuk stok real-time. `keluarObat()`: Kurangi stok di `gudangbarang`, catat mutasi di `riwayat_barang_medis`, dan insert ke `detail_pemberian_obat`. |
| [farmasi.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/farmasi/farmasi.controller.ts) | ~20 | `GET /farmasi/stok` — cek stok. `POST /farmasi/keluar` — keluarkan obat. |
| [farmasi.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/farmasi/farmasi.module.ts) | ~10 | Module definition. |

---

#### Modul `kasir/` — Tagihan & Pembayaran ⭐ (MODUL TERBESAR)

| File | Baris | Fungsi |
|---|---|---|
| [kasir.service.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/kasir/kasir.service.ts) | **313** | ⭐ **File terpenting.** `getTagihan(no_rawat)`: Ambil biaya registrasi dari `reg_periksa`, tindakan dari `rawat_jl_dr` + `jns_perawatan`, obat dari `detail_pemberian_obat` + `databarang`. Hitung grand total. `bayar(no_rawat, nominal)`: (1) Hitung tagihan, (2) Generate `no_nota` & `no_jurnal`, (3) Insert `nota_jalan`, (4) Insert `jurnal` + `detailjurnal` (double-entry: Debit Kas, Kredit Pendapatan), (5) Update `reg_periksa.status_bayar` = 'Sudah Bayar', (6) Update `rawat_jl_dr.stts_bayar` = 'Sudah'. Semua dalam **satu transaksi database** (`$transaction`). |
| [kasir.controller.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/kasir/kasir.controller.ts) | ~25 | `GET /kasir/tagihan/:no_rawat` — lihat tagihan. `POST /kasir/bayar` — proses bayar. |
| [kasir.module.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/src/kasir/kasir.module.ts) | ~8 | Module definition. |

---

### End-to-End Test: `simrs-backend/test/`

| File | Ukuran | Fungsi |
|---|---|---|
| [app.e2e-spec.ts](file:///home/gudang-data-kantor/simrs-web/simrs-backend/test/app.e2e-spec.ts) | 725 B | E2E test scaffold (Supertest + Jest). Test `GET /` → 200. |
| [jest-e2e.json](file:///home/gudang-data-kantor/simrs-web/simrs-backend/test/jest-e2e.json) | 183 B | Jest E2E config: `moduleFileExtensions`, `testRegex`, `transform`. |

---

## 💻 Frontend: `simrs-frontend/`

### Konfigurasi & Root Files

| File | Ukuran | Fungsi |
|---|---|---|
| [index.html](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/index.html) | 366 B | Entry point HTML. Vite inject `<script type="module" src="/src/main.tsx">`. |
| [package.json](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/package.json) | 846 B | Dependencies: `react@^19.2.6`, `react-dom`, `react-router-dom@^7.15.1`, `lucide-react` (ikon). DevDeps: `vite@^8.0.12`, `tailwindcss@^4.3.0`, `typescript@~6.0.2`. |
| [vite.config.ts](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/vite.config.ts) | 220 B | Plugin: `react()`, `tailwindcss()`. Tidak ada proxy ke backend (koneksi langsung via URL). |
| [tsconfig.json](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/tsconfig.json) | 119 B | References: `tsconfig.app.json`, `tsconfig.node.json`. |
| [tsconfig.app.json](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/tsconfig.app.json) | 617 B | TS config untuk kode aplikasi React. |
| [tsconfig.node.json](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/tsconfig.node.json) | 591 B | TS config untuk kode Node/Vite. |
| [eslint.config.js](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/eslint.config.js) | 591 B | Linter config dengan `react-hooks` dan `react-refresh` plugins. |
| [.gitignore](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/.gitignore) | 253 B | Ignore: `node_modules/`, `dist/`. |

### Aset Statis: `public/`

| File | Ukuran | Fungsi |
|---|---|---|
| `favicon.svg` | 9.5 KB | Ikon tab browser. |
| `icons.svg` | 5 KB | Sprite ikon SVG. |

### Aset Diproses: `src/assets/`

| File | Ukuran | Fungsi |
|---|---|---|
| `hero.png` | 13 KB | Gambar hero untuk halaman login/dashboard. |
| `react.svg` | 4.1 KB | Logo React (bawaan Vite scaffold). |
| `vite.svg` | 8.7 KB | Logo Vite (bawaan scaffold). |

### Source Code: `src/`

| File | Baris | Fungsi |
|---|---|---|
| [main.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/main.tsx) | 10 | Mount React app ke `#root` dengan `BrowserRouter`. |
| [App.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/App.tsx) | 29 | **Layout + Routing.** Definisi `<Routes>`: `/login` → Login, `/` → Dashboard, `/registration` → Registration, `/queue` → QueueDisplay, `/bed` → BedManagement, `/rme` → MedicalRecord, `/farmasi` → Farmasi, `/kasir` → Kasir. |
| [App.css](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/App.css) | ~80 | Stylesheet global (layout, warna, spacing). |
| [index.css](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/index.css) | ~15 | CSS reset / base styles. |

### Halaman: `src/pages/`

| File | Baris | Fungsi |
|---|---|---|
| [Login.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/Login.tsx) | 105 | Form login (username + password). Kirim `POST /auth/login`. Simpan JWT di `localStorage`. Redirect ke Dashboard. |
| [Dashboard.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/Dashboard.tsx) | 40 | Halaman utama setelah login. Navigasi menu ke semua modul. |
| [Registration.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/Registration.tsx) | 122 | Form pendaftaran pasien rawat jalan. Input: `no_rkm_medis`, pilih dokter, poli, penjamin. Kirim `POST /registration`. |
| [QueueDisplay.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/QueueDisplay.tsx) | 59 | Display antrean pasien per poliklinik hari ini. Fetch `GET /queue/:poli`. |
| [BedManagement.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/BedManagement.tsx) | 88 | Tampilan ketersediaan kamar rawat inap per bangsal. Fetch `GET /bed/availability`. |
| [MedicalRecord.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/MedicalRecord.tsx) | 295 | UI Rekam Medis Elektronik. Form SOAP (Subjective, Objective, Assessment, Plan). Input diagnosa ICD-10. Tampilkan riwayat CPPT. |
| [Farmasi.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/Farmasi.tsx) | **345** | ⭐ **Halaman terbesar.** Cek stok obat, tampilkan resep, proses pengeluaran obat. Tabel interaktif mutasi gudang. |
| [Kasir.tsx](file:///home/gudang-data-kantor/simrs-web/simrs-frontend/src/pages/Kasir.tsx) | **300** | ⭐ UI tagihan pasien. Input `no_rawat`, tampilkan rincian (registrasi + tindakan + obat). Tombol bayar → kirim `POST /kasir/bayar`. Tampilkan nota + status jurnal. |

---

## 🧪 Simulation & Testing: `simulation/`

### Script Pengujian Per-Modul

| File | Ukuran | Fungsi |
|---|---|---|
| [auth_simulation.py](file:///home/gudang-data-kantor/simrs-web/simulation/auth_simulation.py) | 2 KB | Simulasi login via API, verifikasi JWT token, test akses endpoint terproteksi. |
| [modul1_patient.py](file:///home/gudang-data-kantor/simrs-web/simulation/modul1_patient.py) | 5 KB | Simulasi CRUD pasien. Query `pasien`, validasi format `no_rkm_medis`, test pencarian. |
| [modul2_queue_bed.py](file:///home/gudang-data-kantor/simrs-web/simulation/modul2_queue_bed.py) | 4.1 KB | Simulasi antrean poliklinik + ketersediaan bangsal. Verifikasi relasi `kamar` → `bangsal`. |
| [modul3_rme_cppt.py](file:///home/gudang-data-kantor/simrs-web/simulation/modul3_rme_cppt.py) | 8.6 KB | Simulasi rekam medis. Insert SOAP, diagnosa ICD-10. Verifikasi FK `nip` → `pegawai.nik`. |
| [modul4_farmasi.py](file:///home/gudang-data-kantor/simrs-web/simulation/modul4_farmasi.py) | 3.2 KB | Simulasi stok farmasi. Query `databarang` + `gudangbarang`. Test mutasi keluar. |
| [modul4_1_racikan_simulation.py](file:///home/gudang-data-kantor/simrs-web/simulation/modul4_1_racikan_simulation.py) | 3.1 KB | Simulasi resep racikan. Query `resep_dokter_racikan` + `resep_dokter_racikan_detail`. |
| [modul5_kasir_simulation.py](file:///home/gudang-data-kantor/simrs-web/simulation/modul5_kasir_simulation.py) | 3.6 KB | Simulasi kasir. Hitung tagihan manual, bandingkan dengan API, verifikasi jurnal. |

### Generator Data Dummy

| File | Ukuran | Fungsi |
|---|---|---|
| [generate_sql.py](file:///home/gudang-data-kantor/simrs-web/simulation/generate_sql.py) | 2.5 KB | ⭐ **Generator utama.** Buat 300 `reg_periksa` + `rawat_jl_dr` (1-3 tindakan acak) + `resep_obat` + `detail_pemberian_obat` (1-3 obat acak). Output: `dummy.sql`. Menggunakan pasien existing `000006`. |
| [dummy.sql](file:///home/gudang-data-kantor/simrs-web/simulation/dummy.sql) | **565 KB** | Output SQL dari `generate_sql.py`. 300 registrasi + ~600 tindakan + ~600 obat. Siap import via `mysql < dummy.sql`. |
| [generate_300_dummy.py](file:///home/gudang-data-kantor/simrs-web/simulation/generate_300_dummy.py) | 3.9 KB | Versi lama (koneksi langsung MySQL connector). Gagal karena auth issue. Digantikan `generate_sql.py`. |
| [generate_300_patients.py](file:///home/gudang-data-kantor/simrs-web/simulation/generate_300_patients.py) | 6.5 KB | Versi alternatif generator (lebih lengkap tapi tidak terpakai). |
| [generate_notebook.py](file:///home/gudang-data-kantor/simrs-web/simulation/generate_notebook.py) | 7.1 KB | Script untuk generate Jupyter Notebook simulasi (mock data). |
| [generate_real_db_notebook.py](file:///home/gudang-data-kantor/simrs-web/simulation/generate_real_db_notebook.py) | 3.2 KB | Script untuk generate Jupyter Notebook (koneksi real DB). |

### Validasi & Verifikasi

| File | Ukuran | Fungsi |
|---|---|---|
| [verify_phase1.py](file:///home/gudang-data-kantor/simrs-web/simulation/verify_phase1.py) | 2.6 KB | ⭐ **Validasi single transaksi.** Fetch tagihan → bayar → cek `nota_jalan` → cek `jurnal` → cek `detailjurnal` (debit == kredit) → cek `riwayat_barang_medis`. **LULUS.** |
| [verify_300.py](file:///home/gudang-data-kantor/simrs-web/simulation/verify_300.py) | 2.1 KB | ⭐ **Load test massal.** Loop 300 `no_rawat` → fetch tagihan → bayar. Report: 258 sukses, 42 gagal (collision `no_nota` acak). Output ke `dummy_test_report.json`. |
| [dummy_test_report.json](file:///home/gudang-data-kantor/simrs-web/simulation/dummy_test_report.json) | 6 KB | Hasil JSON dari `verify_300.py`. Detail setiap error (Unique constraint `no_nota`). |

### Utilitas & Notebook

| File | Ukuran | Fungsi |
|---|---|---|
| [dump_schema.py](file:///home/gudang-data-kantor/simrs-web/simulation/dump_schema.py) | 1.2 KB | Dump struktur skema database SIMRS Dummy ke JSON. |
| [test.sql](file:///home/gudang-data-kantor/simrs-web/simulation/test.sql) | 1.7 KB | Snippet SQL untuk testing manual. |
| [simrs_logic_simulation.ipynb](file:///home/gudang-data-kantor/simrs-web/simulation/simrs_logic_simulation.ipynb) | 12.5 KB | Jupyter Notebook: simulasi logika bisnis dengan mock data. |
| [simrs_real_db_simulation.ipynb](file:///home/gudang-data-kantor/simrs-web/simulation/simrs_real_db_simulation.ipynb) | 14.3 KB | Jupyter Notebook: simulasi dengan koneksi real database SIMRS Dummy. |
| `venv/` | Folder | Python virtual environment. **Jangan disentuh.** |

---

## 📋 Dokumen Proyek (Artifacts)

Tersimpan di: `/root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/`

| Dokumen | Ukuran | Fungsi |
|---|---|---|
| [Project_Handover.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Project_Handover.md) | 5.2 KB | **Dokumen serah-terima.** Prompt untuk sesi AI baru, save state, golden rules, cara restart server. |
| [Project_Structure.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Project_Structure.md) | 16.8 KB | Dokumentasi struktur folder (versi ringkas). |
| [Architecture_Analysis.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Architecture_Analysis.md) | 7.2 KB | Analisis arsitektur: mengapa NestJS + Prisma + Vite React. Strategi bridging BPJS (Adapter Pattern, Retry Queue). |
| [Migration_Strategy.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Migration_Strategy.md) | 7.4 KB | Strategi migrasi SIMRS lama → SIMRS-Web. Skenario A (SIMRS Dummy→Web), Skenario B (Vendor lain→Web). Pipeline ETL. **Termasuk: Manajemen Risiko Keamanan Data (IDOR & Obfuscation).** |
| [Data_Standardization_Rules.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Data_Standardization_Rules.md) | 5.2 KB | Aturan standarisasi data: format `no_rkm_medis` (6 digit padded), `no_rawat` (YYYY/MM/DD/NNNNNN), enum gender, dll. |
| [Roadmap.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Roadmap.md) | 2.6 KB | Peta jalan 8 modul (Modul 0–7). Status: Modul 0–5 selesai, Modul 6–7 belum dimulai. |
| [SOP_QnA.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/SOP_QnA.md) | 4.4 KB | QnA standar SOP pengembangan: bagaimana memulai modul baru, aturan simulasi, alur kerja Git. |
| [Operational_QnA.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Operational_QnA.md) | 4.5 KB | QnA operasional: bagaimana alur pendaftaran, tagihan, pembayaran, farmasi, rekam medis di SIMRS ini. |
| [Dummy_Logic_Test_Report.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/Dummy_Logic_Test_Report.md) | 3.4 KB | Laporan hasil uji logika dummy data: skenario test, hasil, kesimpulan. |
| [System_Simplification_Audit.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/System_Simplification_Audit.md) | 5.4 KB | Audit 15 titik penyederhanaan yang dilakukan selama pengembangan. |
| [putangina.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/putangina.md) | 5.4 KB | Dokumen hutang teknis yang JUJUR. Semua penyederhanaan, mulai dari yang ringan hingga krusial. |
| [implementation_plan.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/implementation_plan.md) | 4.8 KB | Rencana implementasi teknis untuk fase yang sedang dikerjakan. |
| [task.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/task.md) | 1.3 KB | Checklist TODO (centang per item). |
| [walkthrough.md](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/walkthrough.md) | 11.6 KB | Rangkuman perjalanan kerja: apa yang sudah dikerjakan, apa yang diuji, hasil validasi. |

### Scratch Files

| File | Lokasi | Fungsi |
|---|---|---|
| [schema_dump.json](file:///root/.gemini/antigravity-cli/brain/8a9f41b6-f995-49d4-9649-31780304d209/scratch/schema_dump.json) | `scratch/` | 143 KB. Dump skema database SIMRS Dummy dalam format JSON (nama tabel, kolom, tipe data). Digunakan untuk referensi cepat tanpa harus query DB. |

---

## 📊 Ringkasan Total

| Kategori | Jumlah File | Total Baris/Ukuran |
|---|---:|---|
| Backend Source (`.ts`) | 32 file | ~841 baris (service only) |
| Frontend Source (`.tsx/.css`) | 12 file | ~1,354 baris (pages only) |
| Prisma Schema | 2 file | 571 baris + 2.3 MB referensi |
| Simulation Scripts (`.py`) | 15 file | ~55 KB |
| Jupyter Notebooks | 2 file | ~27 KB |
| SQL Dumps | 2 file | ~567 KB |
| Konfigurasi (`.json/.mjs/.ts`) | 12 file | — |
| Dokumen Proyek (`.md`) | 14 dokumen | ~87 KB |
| **GRAND TOTAL** | **~89 file relevan** | — |

---

*Dokumen ini adalah inventaris lengkap proyek. Setiap file yang pernah dibuat, diedit, atau digunakan tercatat di sini.*
